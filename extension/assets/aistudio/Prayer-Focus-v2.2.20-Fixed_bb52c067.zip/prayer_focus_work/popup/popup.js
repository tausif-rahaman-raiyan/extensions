import { fetchPrayerTimings, calculateNextPrayer, getPrayerWindows, formatDisplayTime, applyTimeOffset, PRAYER_NAMES } from '../modules/prayer-api.js';
import { getSettings, saveSettings } from '../modules/storage.js';
import { toBengaliNumerals, getPrayerEpoch, getDateStringForTimezone } from '../modules/timezone.js';

let countdownTimer = null;
let currentLang = 'en';
let tahajjudPopupInterval = null;

const POPUP_I18N = {
  en: {
    nextPrayer: "Next Prayer",
    timeLeft: "Time Left:",
    openDashboard: "Open Dashboard",
    settings: "Settings",
    active: "Active",
    disabled: "Disabled",
    limitPrefix: "Until"
  },
  bn: {
    nextPrayer: "পরবর্তী ওয়াক্ত",
    timeLeft: "সময় বাকি:",
    openDashboard: "ড্যাশবোর্ড খুলুন",
    settings: "সেটিংস",
    active: "রিমাইন্ডার সক্রিয়",
    disabled: "বন্ধ রয়েছে",
    limitPrefix: "পর্যন্ত"
  }
};

async function initPopup() {
  const settings = await getSettings();
  currentLang = settings.language || 'en';

  setupPopupLanguageToggle();
  await refreshPopupUI();

  // Hook button handlers
  document.getElementById('btn-open-dashboard')?.addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
    } else {
      window.open('../dashboard/dashboard.html', '_blank');
    }
  });

  document.getElementById('btn-open-settings')?.addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html#settings') });
    } else {
      window.open('../dashboard/dashboard.html#settings', '_blank');
    }
  });
}

function setupPopupLanguageToggle() {
  const btnEn = document.getElementById('btn-popup-en');
  const btnBn = document.getElementById('btn-popup-bn');

  const updateToggleStyle = () => {
    if (btnEn && btnBn) {
      if (currentLang === 'en') {
        btnEn.setAttribute('aria-pressed', 'true');
        btnBn.setAttribute('aria-pressed', 'false');
      } else {
        btnBn.setAttribute('aria-pressed', 'true');
        btnEn.setAttribute('aria-pressed', 'false');
      }
    }
  };

  updateToggleStyle();

  btnEn?.addEventListener('click', async () => {
    if (currentLang === 'en') return;
    currentLang = 'en';
    await saveSettings({ language: 'en' });
    updateToggleStyle();
    await refreshPopupUI();
  });

  btnBn?.addEventListener('click', async () => {
    if (currentLang === 'bn') return;
    currentLang = 'bn';
    await saveSettings({ language: 'bn' });
    updateToggleStyle();
    await refreshPopupUI();
  });
}

async function refreshPopupUI() {
  const settings = await getSettings();
  const dict = POPUP_I18N[currentLang];
  document.documentElement.lang = currentLang === 'bn' ? 'bn' : 'en';

  // Set location label
  const locEl = document.getElementById('location-label');
  if (locEl) locEl.textContent = `${settings.cityName} (${settings.timezone})`;

  // Notifications status
  const statusEl = document.getElementById('status-label');
  if (statusEl) {
    statusEl.textContent = settings.notificationsEnabled ? dict.active : dict.disabled;
    const badge = document.getElementById('reminder-status-badge');
    if (badge) badge.dataset.active = String(Boolean(settings.notificationsEnabled));
  }

  // Label updates
  const labelNext = document.getElementById('label-next-prayer');
  if (labelNext) labelNext.textContent = dict.nextPrayer;

  const labelTimeLeft = document.getElementById('label-time-left');
  if (labelTimeLeft) labelTimeLeft.textContent = dict.timeLeft;

  const labelOpenDash = document.getElementById('label-open-dashboard');
  if (labelOpenDash) labelOpenDash.textContent = dict.openDashboard;

  const labelOpenSet = document.getElementById('label-open-settings');
  if (labelOpenSet) labelOpenSet.textContent = dict.settings;

  // Load schedule
  const schedule = await fetchPrayerTimings();
  if (schedule && schedule.timings) {
    renderMiniTahajjud(schedule, settings);
    const offsets = settings.timingOffsets || {};
    const fmt = settings.timeFormat || '12h';
    const windows = getPrayerWindows(schedule, offsets, fmt);

    for (const [key, rawTime] of Object.entries(schedule.timings)) {
      const timeEl = document.getElementById(`time-${key}`);
      const nameEl = document.getElementById(`name-${key}`);
      const limitEl = document.getElementById(`limit-${key}`);

      if (nameEl && PRAYER_NAMES[key]) {
        nameEl.textContent = currentLang === 'en' ? PRAYER_NAMES[key].en : PRAYER_NAMES[key].bn;
      }

      if (timeEl) {
        const offset = offsets[key] || 0;
        const adjusted = applyTimeOffset(rawTime, offset);
        const formatted = formatDisplayTime(adjusted, fmt);
        timeEl.textContent = currentLang === 'bn' ? toBengaliNumerals(formatted) : formatted;
      }

      if (limitEl && windows[key]) {
        const win = windows[key];
        const endFmt = win.end;
        limitEl.textContent = currentLang === 'bn' 
          ? `সীমা: ${toBengaliNumerals(endFmt)}`
          : `Limit: ${endFmt}`;
      }
    }

    startLiveCountdown(schedule, settings);
  }
}

function startLiveCountdown(schedule, settings = {}) {
  if (countdownTimer) clearInterval(countdownTimer);
  const offsets = settings.timingOffsets || {};
  const fmt = settings.timeFormat || '12h';

  const update = () => {
    const nextInfo = calculateNextPrayer(schedule, offsets);
    if (!nextInfo || !nextInfo.next) return;

    const next = nextInfo.next;
    const nameEl = document.getElementById('next-prayer-name');
    const timeEl = document.getElementById('next-prayer-time');
    const limitEl = document.getElementById('next-prayer-limit');
    const countEl = document.getElementById('countdown-text');

    if (nameEl) {
      nameEl.textContent = currentLang === 'bn' ? `${next.name} (${next.arabicName})` : `${next.nameEn} (${next.arabicName})`;
    }
    if (timeEl) {
      const formatted = formatDisplayTime(next.time, fmt);
      timeEl.textContent = currentLang === 'bn' ? toBengaliNumerals(formatted) : formatted;
    }
    if (limitEl) {
      const winStr = currentLang === 'bn' ? next.windowBn : next.windowEn;
      const limitLabel = currentLang === 'bn' ? next.limitBn : next.limitEn;
      limitEl.textContent = currentLang === 'bn'
        ? `সময়সীমা: ${toBengaliNumerals(winStr)} (${limitLabel})`
        : `Time Window: ${winStr} (${limitLabel})`;
    }

    // Present Salah / Current Window banner
    const presentBanner = document.getElementById('present-prayer-banner');
    const presentTitle = document.getElementById('present-prayer-title');
    const presentRange = document.getElementById('present-prayer-time-range');
    if (presentBanner && presentTitle && presentRange) {
      if (nextInfo.current) {
        const cur = nextInfo.current;
        const curName = currentLang === 'bn' ? cur.name : cur.nameEn;
        const curWin = currentLang === 'bn' ? toBengaliNumerals(cur.windowBn || '') : (cur.windowEn || '');
        presentBanner.style.display = 'flex';
        presentTitle.textContent = `${currentLang === 'bn' ? 'বর্তমান ওয়াক্ত:' : 'Present Window:'} ${curName}`;
        presentRange.textContent = curWin;
      } else {
        presentBanner.style.display = 'none';
      }
    }

    // Highlight current active prayer in grid
    document.querySelectorAll('.grid-item').forEach((item) => {
      if (nextInfo.current && item.getAttribute('data-key') === nextInfo.current.key) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    const diff = Math.max(0, next.epoch - Date.now());
    const totalSec = Math.floor(diff / 1000);
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;

    const formatted = `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    if (countEl) countEl.textContent = currentLang === 'bn' ? toBengaliNumerals(formatted) : formatted;
  };

  update();
  countdownTimer = setInterval(update, 1000);
}

function renderMiniTahajjud(schedule, settings) {
  if (tahajjudPopupInterval) {
    clearInterval(tahajjudPopupInterval);
    tahajjudPopupInterval = null;
  }
  const startEl = document.getElementById('mini-tahajjud-start');
  const endEl = document.getElementById('mini-tahajjud-end');
  const countdownEl = document.getElementById('mini-tahajjud-countdown');
  if (!startEl || !endEl || !countdownEl || !schedule?.timings?.fajr || !schedule?.timings?.isha) return;
  const timezone = settings.timezone || 'Asia/Dhaka';
  const date = schedule.date || getDateStringForTimezone(new Date(), timezone);
  const [y,m,d] = date.split('-').map(Number);
  const tomorrowDate = new Date(Date.UTC(y,m-1,d+1));
  const tomorrow = `${tomorrowDate.getUTCFullYear()}-${String(tomorrowDate.getUTCMonth()+1).padStart(2,'0')}-${String(tomorrowDate.getUTCDate()).padStart(2,'0')}`;
  const offsets = settings.timingOffsets || {};
  const adjusted = (time, offset=0) => { const [hh,mm] = time.split(':').map(Number); const dt = new Date(Date.UTC(2000,0,1,hh,mm+(Number(offset)||0))); return `${String(dt.getUTCHours()).padStart(2,'0')}:${String(dt.getUTCMinutes()).padStart(2,'0')}`; };
  const todayFajr = getPrayerEpoch(date, adjusted(schedule.timings.fajr, offsets.fajr), timezone);
  const todayIsha = getPrayerEpoch(date, adjusted(schedule.timings.isha, offsets.isha), timezone);
  const tomorrowFajr = Number.isFinite(schedule.tomorrowFajrEpoch) ? schedule.tomorrowFajrEpoch + (Number(offsets.fajr)||0)*60000 : getPrayerEpoch(tomorrow, adjusted(schedule.timings.fajr, offsets.fajr), timezone);
  const prevDate = new Date(Date.UTC(y,m-1,d-1));
  const prevIso = `${prevDate.getUTCFullYear()}-${String(prevDate.getUTCMonth()+1).padStart(2,'0')}-${String(prevDate.getUTCDate()).padStart(2,'0')}`;
  const previousIsha = Number.isFinite(schedule.yesterdayIshaEpoch) ? schedule.yesterdayIshaEpoch + (Number(offsets.isha)||0)*60000 : getPrayerEpoch(prevIso, adjusted(schedule.timings.isha, offsets.isha), timezone);
  const fmt = epoch => new Intl.DateTimeFormat(currentLang==='bn'?'bn-BD':'en-US',{timeZone:timezone,hour:'numeric',minute:'2-digit',hour12:(settings.timeFormat||'12h')!=='24h'}).format(new Date(epoch));
  const activeOvernight = Date.now() < todayFajr;
  const startEpoch = activeOvernight ? previousIsha : todayIsha;
  const endEpoch = activeOvernight ? todayFajr : tomorrowFajr;
  const apiIshaMissing = activeOvernight && !Number.isFinite(schedule.yesterdayIshaEpoch);
  startEl.textContent = apiIshaMissing ? (currentLang === 'bn' ? 'এশার পর' : 'After Isha') : fmt(startEpoch);
  endEl.textContent = fmt(endEpoch);
  const tick = () => {
    const now = Date.now(); const inside = now >= startEpoch && now < endEpoch;
    const target = inside ? endEpoch : (now < startEpoch ? startEpoch : tomorrowFajr);
    let secs = Math.max(0, Math.floor((target-now)/1000));
    const hh=String(Math.floor(secs/3600)).padStart(2,'0'); const mm=String(Math.floor((secs%3600)/60)).padStart(2,'0'); const ss=String(secs%60).padStart(2,'0');
    const digits=`${hh}:${mm}:${ss}`; countdownEl.textContent=currentLang==='bn'?toBengaliNumerals(digits):digits;
    const status=document.getElementById('mini-tahajjud-status'); if(status) status.textContent=currentLang==='bn'?(inside?'চলমান':'আসন্ন'):(inside?'IN WINDOW':'UPCOMING');
    const label=document.getElementById('mini-tahajjud-count-label'); if(label) label.textContent=currentLang==='bn'?(inside?'ফজর পর্যন্ত':'শুরু হতে বাকি'):(inside?'Until Fajr':'Starts in');
    const startLabel=document.getElementById('mini-tahajjud-start-label'); const endLabel=document.getElementById('mini-tahajjud-end-label');
    if(startLabel) startLabel.textContent=currentLang==='bn'?'এশার পর':'After Isha'; if(endLabel) endLabel.textContent=currentLang==='bn'?'ফজরের আগে':'Before Fajr';
    const title=document.getElementById('mini-tahajjud-title'); if(title) title.textContent=currentLang==='bn'?'তাহাজ্জুদ':'Tahajjud';
  };
  tick(); tahajjudPopupInterval=setInterval(tick,1000);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPopup, { once: true });
} else {
  initPopup();
}
