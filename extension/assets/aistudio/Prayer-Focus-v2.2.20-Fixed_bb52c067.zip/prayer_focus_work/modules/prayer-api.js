import { getPrayerEpoch, getDateStringForTimezone } from './timezone.js';
import { getStorageData, setStorageData, getSettings } from './storage.js';

export const PRAYER_NAMES = {
  fajr: { bn: 'ফজর', en: 'Fajr', ar: 'الفجر' },
  dhuhr: { bn: 'যোহর', en: 'Dhuhr', ar: 'الظهر' },
  asr: { bn: 'আসর', en: 'Asr', ar: 'العصر' },
  maghrib: { bn: 'মাগরিব', en: 'Maghrib', ar: 'المغرب' },
  isha: { bn: 'এশা', en: 'Isha', ar: 'العشاء' }
};

const DHAKA_TZ = 'Asia/Dhaka';
const TIME_KEYS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
const PROVIDER_TIMEOUT_MS = 8500;

function isValidTime(value) {
  return typeof value === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
}

function cleanTime(value, timezone = DHAKA_TZ) {
  if (typeof value === 'string') {
    const match = value.match(/(?:^|\s)([01]?\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?(?:\s|$)/);
    if (match) return `${String(Number(match[1])).padStart(2, '0')}:${match[2]}`;
    const date = new Date(value);
    if (!Number.isNaN(date.getTime())) {
      return new Intl.DateTimeFormat('en-GB', {
        timeZone: timezone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
      }).format(date);
    }
  }
  if (typeof value === 'number') {
    const date = new Date(value > 1e12 ? value : value * 1000);
    if (!Number.isNaN(date.getTime())) {
      return new Intl.DateTimeFormat('en-GB', {
        timeZone: timezone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
      }).format(date);
    }
  }
  return null;
}

function dateForSettings(settings, now = new Date()) {
  return getDateStringForTimezone(now, settings.timezone || DHAKA_TZ);
}

function makeUrl(base, params) {
  const url = new URL(base);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, String(value));
  });
  return url.toString();
}

async function fetchJson(url, provider) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), PROVIDER_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      cache: 'no-store',
      headers: { Accept: 'application/json' }
    });
    if (!response.ok) throw new Error(`${provider}: HTTP ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timeout);
  }
}

function assertProviderDate(value, provider, todayStr, timezone = DHAKA_TZ) {
  if (!value) return;
  let normalized = null;
  if (typeof value === 'string') {
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) normalized = value;
    else if (/^\d{2}-\d{2}-\d{4}$/.test(value)) {
      const [d, m, y] = value.split('-'); normalized = `${y}-${m}-${d}`;
    } else {
      const parsed = new Date(value);
      if (!Number.isNaN(parsed.getTime())) normalized = getDateStringForTimezone(parsed, timezone);
    }
  } else if (typeof value === 'number') {
    normalized = getDateStringForTimezone(new Date(value > 1e12 ? value : value * 1000), timezone);
  }
  if (normalized && normalized !== todayStr) throw new Error(`${provider}: date mismatch (${normalized})`);
}

function validateSchedule(rawTimings, provider, todayStr, settings, extra = {}) {
  if (!rawTimings || typeof rawTimings !== 'object') throw new Error(`${provider}: missing timings object`);
  const timings = {};
  for (const key of TIME_KEYS) {
    const sourceKey = key[0].toUpperCase() + key.slice(1);
    const value = cleanTime(rawTimings[key] ?? rawTimings[sourceKey], settings.timezone || DHAKA_TZ);
    if (!isValidTime(value)) throw new Error(`${provider}: invalid ${sourceKey}`);
    timings[key] = value;
  }
  const sunrise = cleanTime(rawTimings.sunrise ?? rawTimings.Sunrise, settings.timezone || DHAKA_TZ);
  if (!isValidTime(sunrise)) throw new Error(`${provider}: invalid Sunrise`);

  // Reject obviously malformed or internally out-of-order provider responses.
  const ordered = [timings.fajr, sunrise, timings.dhuhr, timings.asr, timings.maghrib, timings.isha]
    .map(t => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5)));
  if (ordered.some((v, i) => i > 0 && v <= ordered[i - 1])) {
    throw new Error(`${provider}: prayer times are not in chronological order`);
  }

  const timezone = settings.timezone || DHAKA_TZ;
  const fajrEpoch = getPrayerEpoch(todayStr, timings.fajr, timezone);
  const ishaEpoch = getPrayerEpoch(todayStr, timings.isha, timezone);
  return {
    date: todayStr,
    timezone,
    syncTime: Date.now(),
    provider,
    methodName: extra.methodName || `${provider} (${settings.calculationMethod ?? 1}; ${settings.asrMethod === 1 ? 'Hanafi' : 'Shafi'})`,
    timings,
    sunrise,
    sunset: timings.maghrib,
    yesterdayIshaEpoch: Number.isFinite(extra.yesterdayIshaEpoch) ? extra.yesterdayIshaEpoch : null,
    tomorrowFajrEpoch: Number.isFinite(extra.tomorrowFajrEpoch) ? extra.tomorrowFajrEpoch : null,
    source: extra.source || 'api',
    providerStatus: extra.providerStatus || []
  };
}

async function fetchProthomAlo(todayStr, settings) {
  // Bangladesh-specific timetable feed; accept it only if its complete schema validates.
  const payload = await fetchJson('https://services.prothomalo.com/api/prayer-time?v=1', 'Prothom Alo');
  const raw = payload?.data || payload?.prayerTimes || payload;
  if (!raw || typeof raw !== 'object') throw new Error('Prothom Alo: unexpected response');
  let sourceDate = null;
  if (typeof raw.date === 'string') {
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw.date)) sourceDate = raw.date;
    else if (/^\d{2}-\d{2}-\d{4}$/.test(raw.date)) {
      const [d, m, y] = raw.date.split('-'); sourceDate = `${y}-${m}-${d}`;
    } else {
      const parsed = new Date(raw.date);
      if (!Number.isNaN(parsed.getTime())) sourceDate = getDateStringForTimezone(parsed, settings.timezone || DHAKA_TZ);
    }
  } else if (typeof raw.date === 'number') {
    sourceDate = getDateStringForTimezone(new Date(raw.date > 1e12 ? raw.date : raw.date * 1000), settings.timezone || DHAKA_TZ);
  }
  if (!sourceDate) throw new Error('Prothom Alo: response does not include a verifiable date');
  if (sourceDate !== todayStr) throw new Error(`Prothom Alo: date mismatch (${sourceDate})`);
  const schedule = validateSchedule(raw, 'Islamic Foundation Bangladesh via Prothom Alo', todayStr, settings, {
    source: 'bangladesh', methodName: 'Bangladesh timetable (Prothom Alo feed)'
  });
  return schedule;
}

async function fetchSitp(todayStr, settings) {
  const sitpMethods = { 1: 'karachi', 2: 'isna', 3: 'mwl', 4: 'makkah', 5: 'egypt' };
  const url = makeUrl('https://api.sitp.app/api/v1/prayer-times/', {
    latitude: settings.latitude, longitude: settings.longitude,
    timezone_str: settings.timezone || DHAKA_TZ,
    method: sitpMethods[settings.calculationMethod] || 'karachi'
  });
  const payload = await fetchJson(url, 'SITP');
  assertProviderDate(payload?.date || payload?.data?.date, 'SITP', todayStr, settings.timezone || DHAKA_TZ);
  const raw = payload?.data?.timings || payload?.timings || payload?.data || payload;
  return validateSchedule(raw, 'SITP', todayStr, settings, { methodName: `SITP ${sitpMethods[settings.calculationMethod] || 'Karachi'} calculation` });
}

async function fetchIslamicApp(todayStr, settings) {
  const [year, month, day] = todayStr.split('-');
  const date = `${day}-${month}-${year}`;
  const url = makeUrl(`https://api.islamic.app/v1/timings/${date}`, {
    latitude: settings.latitude, longitude: settings.longitude,
    timezone: settings.timezone || DHAKA_TZ,
    method: settings.calculationMethod ?? 1,
    school: settings.asrMethod ?? 1
  });
  const payload = await fetchJson(url, 'islamic.app');
  if (payload?.code !== 200 || !payload?.data?.timings) throw new Error('islamic.app: invalid response');
  assertProviderDate(payload?.data?.date?.readable, 'islamic.app', todayStr, settings.timezone || DHAKA_TZ);
  return validateSchedule(payload.data.timings, 'islamic.app', todayStr, settings, {
    methodName: `islamic.app method ${settings.calculationMethod ?? 1}`
  });
}

async function fetchAlAdhan(todayStr, settings) {
  const [year, month, day] = todayStr.split('-');
  const date = `${day}-${month}-${year}`; // AlAdhan requires DD-MM-YYYY, not ISO.
  const url = makeUrl(`https://api.aladhan.com/v1/timings/${date}`, {
    latitude: settings.latitude, longitude: settings.longitude,
    method: settings.calculationMethod ?? 1,
    school: settings.asrMethod ?? 1,
    timezonestring: settings.timezone || DHAKA_TZ
  });
  const payload = await fetchJson(url, 'AlAdhan');
  if (payload?.code !== 200 || !payload?.data?.timings) throw new Error('AlAdhan: invalid response');
  assertProviderDate(payload?.data?.date?.gregorian?.date, 'AlAdhan', todayStr, settings.timezone || DHAKA_TZ);
  return validateSchedule(payload.data.timings, 'AlAdhan', todayStr, settings, {
    methodName: `AlAdhan method ${settings.calculationMethod ?? 1}`
  });
}



async function fetchYesterdayIshaFromAlAdhan(todayStr, settings) {
  const timezone = settings.timezone || DHAKA_TZ;
  const [year, month, day] = todayStr.split('-').map(Number);
  const yesterdayDateObj = new Date(Date.UTC(year, month - 1, day - 1));
  const yesterdayIso = `${yesterdayDateObj.getUTCFullYear()}-${String(yesterdayDateObj.getUTCMonth() + 1).padStart(2, '0')}-${String(yesterdayDateObj.getUTCDate()).padStart(2, '0')}`;
  const [y, m, d] = yesterdayIso.split('-');
  const url = makeUrl(`https://api.aladhan.com/v1/timings/${d}-${m}-${y}`, {
    latitude: settings.latitude, longitude: settings.longitude,
    method: settings.calculationMethod ?? 1,
    school: settings.asrMethod ?? 1,
    timezonestring: timezone
  });
  const payload = await fetchJson(url, 'AlAdhan yesterday Isha');
  if (payload?.code !== 200 || !payload?.data?.timings?.Isha) throw new Error('AlAdhan yesterday Isha: invalid response');
  assertProviderDate(payload?.data?.date?.gregorian?.date, 'AlAdhan yesterday Isha', yesterdayIso, timezone);
  const isha = cleanTime(payload.data.timings.Isha, timezone);
  if (!isValidTime(isha)) throw new Error('AlAdhan yesterday Isha: invalid time');
  return getPrayerEpoch(yesterdayIso, isha, timezone);
}

async function fetchTomorrowFajrFromAlAdhan(todayStr, settings) {
  const timezone = settings.timezone || DHAKA_TZ;
  const [year, month, day] = todayStr.split('-').map(Number);
  const tomorrowDateObj = new Date(Date.UTC(year, month - 1, day + 1));
  const tomorrowIso = `${tomorrowDateObj.getUTCFullYear()}-${String(tomorrowDateObj.getUTCMonth() + 1).padStart(2, '0')}-${String(tomorrowDateObj.getUTCDate()).padStart(2, '0')}`;
  const [ty, tm, td] = tomorrowIso.split('-');
  const url = makeUrl(`https://api.aladhan.com/v1/timings/${td}-${tm}-${ty}`, {
    latitude: settings.latitude, longitude: settings.longitude,
    method: settings.calculationMethod ?? 1,
    school: settings.asrMethod ?? 1,
    timezonestring: timezone
  });
  const payload = await fetchJson(url, 'AlAdhan tomorrow Fajr');
  if (payload?.code !== 200 || !payload?.data?.timings?.Fajr) throw new Error('AlAdhan tomorrow Fajr: invalid response');
  assertProviderDate(payload?.data?.date?.gregorian?.date, 'AlAdhan tomorrow Fajr', tomorrowIso, timezone);
  const fajr = cleanTime(payload.data.timings.Fajr, timezone);
  if (!isValidTime(fajr)) throw new Error('AlAdhan tomorrow Fajr: invalid time');
  return getPrayerEpoch(tomorrowIso, fajr, timezone);
}

/**
 * Query four independent sources in parallel. The Bangladesh timetable is preferred
 * when its response validates; otherwise use the first valid location-based provider.
 * Times are never averaged because providers may use different calculation conventions.
 */
export async function fetchPrayerTimings(forceRefresh = false) {
  const settings = await getSettings();
  const timezone = settings.timezone || DHAKA_TZ;
  const todayStr = dateForSettings(settings);
  const locationKey = [settings.cityName, settings.latitude, settings.longitude, timezone,
    settings.calculationMethod, settings.asrMethod, settings.prayerApiProvider || 'auto'].join('_').toLowerCase().replace(/[^a-z0-9_.-]+/g, '-');
  const cacheKey = `prayer_cache_${locationKey}_${todayStr}`;
  const attemptKey = `prayer_api_attempt_${locationKey}_${todayStr}`;

  if (!forceRefresh) {
    const cached = await getStorageData([cacheKey]);
    if (cached[cacheKey]?.scheduleVersion === 3 && cached[cacheKey]?.timings && cached[cacheKey]?.date === todayStr && cached[cacheKey]?.timezone === timezone) {
      return cached[cacheKey];
    }
  }

  if (!forceRefresh) {
    const attemptData = await getStorageData([attemptKey]);
    const attempt = attemptData[attemptKey];
    // Avoid repeatedly hitting external APIs from the one-minute prayer monitor.
    // A short lease allows recovery if Chrome stopped during an in-flight request.
    if (attempt?.status === 'failed' || (attempt?.status === 'fetching' && Date.now() - attempt.at < 5 * 60 * 1000)) {
      return null;
    }
  }
  await setStorageData({ [attemptKey]: { status: 'fetching', at: Date.now(), date: todayStr } });

  const isBangladesh = /bangladesh|বাংলাদেশ/i.test(settings.cityName || '') ||
    (Number(settings.latitude) >= 20 && Number(settings.latitude) <= 27 && Number(settings.longitude) >= 88 && Number(settings.longitude) <= 93);
  const allJobs = [
    { id: 'bangladesh', name: 'Bangladesh timetable', enabled: isBangladesh, run: () => fetchProthomAlo(todayStr, settings) },
    { id: 'islamic_app', name: 'islamic.app', enabled: true, run: () => fetchIslamicApp(todayStr, settings) },
    { id: 'sitp', name: 'SITP', enabled: true, run: () => fetchSitp(todayStr, settings) },
    { id: 'aladhan', name: 'AlAdhan', enabled: true, run: () => fetchAlAdhan(todayStr, settings) }
  ];
  const selectedProvider = settings.prayerApiProvider || 'auto';
  const enabledJobs = allJobs.filter(job => job.enabled);
  // A chosen provider is a preference, not a single point of failure.
  // If it fails, continue through the remaining valid providers.
  const preferred = selectedProvider === 'auto'
    ? enabledJobs
    : allJobs.filter(job => job.id === selectedProvider && job.enabled);
  const jobs = selectedProvider === 'auto'
    ? preferred
    : [...preferred, ...enabledJobs.filter(job => job.id !== selectedProvider)];
  if (!jobs.length) {
    await setStorageData({ [attemptKey]: { status: 'failed', at: Date.now(), date: todayStr, errors: ['Selected provider is not available for this location'] } });
    return null;
  }

  const results = await Promise.all(jobs.map(async job => {
    try { return { name: job.name, schedule: await job.run() }; }
    catch (error) {
      console.warn(`[Prayer Focus] ${job.name} unavailable:`, error?.message || error);
      return { name: job.name, error: error?.message || String(error) };
    }
  }));

  const selected = results.find(result => result.schedule);
  if (selected) {
    const [tomorrowFajrResult, yesterdayIshaResult] = await Promise.allSettled([
      fetchTomorrowFajrFromAlAdhan(todayStr, settings),
      fetchYesterdayIshaFromAlAdhan(todayStr, settings)
    ]);
    const tomorrowFajrEpoch = tomorrowFajrResult.status === 'fulfilled' ? tomorrowFajrResult.value : null;
    const yesterdayIshaEpoch = yesterdayIshaResult.status === 'fulfilled' ? yesterdayIshaResult.value : null;
    if (!Number.isFinite(tomorrowFajrEpoch)) console.warn('[Prayer Focus] Tomorrow Fajr lookup unavailable:', tomorrowFajrResult.reason?.message || tomorrowFajrResult.reason);
    if (!Number.isFinite(yesterdayIshaEpoch)) console.warn('[Prayer Focus] Yesterday Isha lookup unavailable:', yesterdayIshaResult.reason?.message || yesterdayIshaResult.reason);
    const schedule = {
      ...selected.schedule,
      scheduleVersion: 3,
      ...(Number.isFinite(tomorrowFajrEpoch) ? { tomorrowFajrEpoch } : { tomorrowFajrUnavailable: true }),
      ...(Number.isFinite(yesterdayIshaEpoch) ? { yesterdayIshaEpoch } : { yesterdayIshaUnavailable: true }),
      providerStatus: results.map(r => ({ provider: r.name, ok: Boolean(r.schedule), error: r.error || null })),
      providersChecked: results.length
    };
    await setStorageData({
      [cacheKey]: schedule,
      last_prayer_schedule: schedule,
      last_prayer_location_key: locationKey,
      last_sync_timestamp: Date.now(),
      [attemptKey]: { status: 'success', at: Date.now(), date: todayStr, provider: selected.name }
    });
    return schedule;
  }

  // A same-day cache for the exact same location/settings is the only offline fallback.
  const fallbackCache = await getStorageData(['last_prayer_schedule', 'last_prayer_location_key']);
  if (fallbackCache.last_prayer_location_key === locationKey &&
      fallbackCache.last_prayer_schedule?.date === todayStr &&
      fallbackCache.last_prayer_schedule?.timings) {
    return { ...fallbackCache.last_prayer_schedule, isCachedFallback: true,
      providerStatus: results.map(r => ({ provider: r.name, ok: false, error: r.error || 'Unavailable' })) };
  }

  await setStorageData({ [attemptKey]: { status: 'failed', at: Date.now(), date: todayStr, errors: results.map(r => r.error || null) } });
  console.error('[Prayer Focus] All prayer-time providers failed:', results);
  return null;
}

/** Applies minute offset to a HH:mm string. */
export function applyTimeOffset(timeStr, offsetMinutes = 0) {
  if (!offsetMinutes || isNaN(offsetMinutes)) return timeStr;
  const [h, m] = timeStr.split(':').map(Number);
  const totalMin = (h * 60 + m + Number(offsetMinutes) + 1440) % 1440;
  return `${String(Math.floor(totalMin / 60)).padStart(2, '0')}:${String(totalMin % 60).padStart(2, '0')}`;
}

export function formatDisplayTime(timeStr, format = '12h') {
  if (!timeStr || !timeStr.includes(':')) return timeStr;
  if (format === '24h') return timeStr;
  const [h, m] = timeStr.split(':').map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

export function getPrayerWindows(schedule, offsets = {}, format = '12h') {
  if (!schedule?.timings) return {};
  const fajrRaw = applyTimeOffset(schedule.timings.fajr, offsets.fajr || 0);
  const sunriseRaw = schedule.sunrise || '06:00';
  const dhuhrRaw = applyTimeOffset(schedule.timings.dhuhr, offsets.dhuhr || 0);
  const asrRaw = applyTimeOffset(schedule.timings.asr, offsets.asr || 0);
  const maghribRaw = applyTimeOffset(schedule.timings.maghrib, offsets.maghrib || 0);
  const ishaRaw = applyTimeOffset(schedule.timings.isha, offsets.isha || 0);
  const fmt = (t) => formatDisplayTime(t, format);
  return {
    fajr: { start: fmt(fajrRaw), end: fmt(sunriseRaw), limitEn: `Until Sunrise (${fmt(sunriseRaw)})`, limitBn: `সূর্যোদয় (${fmt(sunriseRaw)}) পর্যন্ত`, windowEn: `${fmt(fajrRaw)} – ${fmt(sunriseRaw)}`, windowBn: `${fmt(fajrRaw)} – ${fmt(sunriseRaw)}` },
    dhuhr: { start: fmt(dhuhrRaw), end: fmt(asrRaw), limitEn: `Until Asr (${fmt(asrRaw)})`, limitBn: `আসর (${fmt(asrRaw)}) পর্যন্ত`, windowEn: `${fmt(dhuhrRaw)} – ${fmt(asrRaw)}`, windowBn: `${fmt(dhuhrRaw)} – ${fmt(asrRaw)}` },
    asr: { start: fmt(asrRaw), end: fmt(maghribRaw), limitEn: `Until Maghrib (${fmt(maghribRaw)})`, limitBn: `মাগরিব (${fmt(maghribRaw)}) পর্যন্ত`, windowEn: `${fmt(asrRaw)} – ${fmt(maghribRaw)}`, windowBn: `${fmt(asrRaw)} – ${fmt(maghribRaw)}` },
    maghrib: { start: fmt(maghribRaw), end: fmt(ishaRaw), limitEn: `Until Isha (${fmt(ishaRaw)})`, limitBn: `এশা (${fmt(ishaRaw)}) পর্যন্ত`, windowEn: `${fmt(maghribRaw)} – ${fmt(ishaRaw)}`, windowBn: `${fmt(maghribRaw)} – ${fmt(ishaRaw)}` },
    isha: { start: fmt(ishaRaw), end: fmt(fajrRaw), limitEn: `Until Fajr (${fmt(fajrRaw)})`, limitBn: `ফজর (${fmt(fajrRaw)}) পর্যন্ত`, windowEn: `${fmt(ishaRaw)} – ${fmt(fajrRaw)}`, windowBn: `${fmt(ishaRaw)} – ${fmt(fajrRaw)}` }
  };
}

export function calculateNextPrayer(schedule, offsets = {}) {
  if (!schedule?.timings) return null;
  const now = Date.now();
  const dateStr = schedule.date;
  const windows = getPrayerWindows(schedule, offsets);
  const sunriseEpoch = getPrayerEpoch(dateStr, schedule.sunrise || '06:00', schedule.timezone || DHAKA_TZ);
  const list = TIME_KEYS.map((key) => {
    const rawTime = schedule.timings[key];
    const timeStr = applyTimeOffset(rawTime, offsets[key] || 0);
    const epoch = getPrayerEpoch(dateStr, timeStr, schedule.timezone || DHAKA_TZ);
    const win = windows[key] || {};
    return { key, name: PRAYER_NAMES[key].bn, nameEn: PRAYER_NAMES[key].en, arabicName: PRAYER_NAMES[key].ar, time: timeStr, rawTime, offsetMin: offsets[key] || 0, epoch, limitEn: win.limitEn || '', limitBn: win.limitBn || '', windowEn: win.windowEn || '', windowBn: win.windowBn || '' };
  });
  list[0].endEpoch = sunriseEpoch;
  list[1].endEpoch = list[2].epoch;
  list[2].endEpoch = list[3].epoch;
  list[3].endEpoch = list[4].epoch;
  list[4].endEpoch = list[0].epoch + 86400000;
  let currentPrayer = null;
  let nextPrayer = null;
  for (let i = 0; i < list.length; i++) {
    if (now >= list[i].epoch) currentPrayer = list[i];
    else { nextPrayer = list[i]; break; }
  }
  if (currentPrayer && (now >= currentPrayer.endEpoch || now < currentPrayer.epoch)) currentPrayer = null;
  if (!nextPrayer) nextPrayer = { ...list[0], epoch: list[0].epoch + 86400000, isTomorrow: true };
  return { current: currentPrayer, next: nextPrayer, all: list, windows, timeRemainingMs: Math.max(0, nextPrayer.epoch - now) };
}
