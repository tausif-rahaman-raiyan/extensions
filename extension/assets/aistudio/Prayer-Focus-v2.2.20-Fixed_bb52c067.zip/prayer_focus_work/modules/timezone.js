/**
 * Timezone helpers for Asia/Dhaka (UTC+6, no DST)
 */
export const DHAKA_TIMEZONE = 'Asia/Dhaka';

/**
 * Returns current Date adjusted to Asia/Dhaka timezone representation
 */
export function getDhakaNow() {
  const now = new Date();
  const dhakaString = now.toLocaleString('en-US', { timeZone: DHAKA_TIMEZONE });
  return new Date(dhakaString);
}

export function getNowForTimezone(timezone = DHAKA_TIMEZONE, date = new Date()) {
  const localString = date.toLocaleString('en-US', { timeZone: timezone });
  return new Date(localString);
}

export function getTodayDateString(timezone = DHAKA_TIMEZONE, date = new Date()) {
  return getDateStringForTimezone(date, timezone);
}

export function formatDateForTimezone(date = new Date(), timezone = DHAKA_TIMEZONE, locale = 'en-US') {
  return new Intl.DateTimeFormat(locale, {
    timeZone: timezone, weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  }).format(date);
}

export function formatTimeForTimezone(date = new Date(), timezone = DHAKA_TIMEZONE, locale = 'en-US', hour12 = true) {
  return new Intl.DateTimeFormat(locale, {
    timeZone: timezone, hour: 'numeric', minute: '2-digit', second: '2-digit', hour12
  }).format(date);
}

/**
 * Returns today's date formatted as YYYY-MM-DD in Asia/Dhaka
 */
export function getDhakaDateString(date = new Date()) {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: DHAKA_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  return formatter.format(date);
}

/**
 * Format date in Bengali readable form
 */
export function formatBengaliDate(date = new Date(), timezone = DHAKA_TIMEZONE) {
  const options = {
    timeZone: timezone,
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };
  return new Intl.DateTimeFormat('bn-BD', options).format(date);
}

/**
 * Format time in 12-hour or 24-hour Bengali format
 */
export function formatBengaliTime(date = new Date(), timezone = DHAKA_TIMEZONE) {
  const options = {
    timeZone: timezone,
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  };
  return new Intl.DateTimeFormat('bn-BD', options).format(date);
}

/**
 * Convert English digits to Bengali digits
 */
export function toBengaliNumerals(num) {
  if (num === undefined || num === null) return '';
  const str = String(num);
  const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/[0-9]/g, (w) => bengaliDigits[+w]);
}

/**
 * Converts a HH:mm prayer time string on a given date to an epoch in the supplied IANA timezone
 */
export function getPrayerEpoch(dateStr, timeStr, timezone = DHAKA_TIMEZONE) {
  const cleanTime = String(timeStr || '').split(' ')[0].trim();
  const [year, month, day] = String(dateStr).split('-').map(Number);
  const [hours, minutes] = cleanTime.split(':').map(Number);
  if (![year, month, day, hours, minutes].every(Number.isFinite)) return NaN;

  // Convert a local wall-clock time in any IANA timezone to a UTC epoch.
  // Two passes handle timezone offsets and DST transitions without assuming UTC+6.
  const utcGuess = Date.UTC(year, month - 1, day, hours, minutes, 0);
  const partsFor = (date) => Object.fromEntries(
    new Intl.DateTimeFormat('en-GB', {
      timeZone: timezone || DHAKA_TIMEZONE,
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
    }).formatToParts(date).filter(p => p.type !== 'literal').map(p => [p.type, Number(p.value)])
  );
  let epoch = utcGuess;
  for (let i = 0; i < 2; i++) {
    const p = partsFor(new Date(epoch));
    const represented = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
    epoch = utcGuess - (represented - epoch);
  }
  return epoch;
}

export function getDateStringForTimezone(date = new Date(), timezone = DHAKA_TIMEZONE) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone || DHAKA_TIMEZONE,
    year: 'numeric', month: '2-digit', day: '2-digit'
  }).format(date);
}
