# Prayer Focus – Pray • Focus • Grow
**Version: 2.2.0**  
Platform: Google Chrome (Manifest V3)  
Default Location: Chattogram, Bangladesh  
Timezone: `Asia/Dhaka` (UTC+6, strictly handled without DST assumptions)

---

## 📸 Screenshots & Visual Preview

### 1. Main Dashboard & Current Prayer Window
![Prayer Focus Main Dashboard Overview](../public/assets/aistudio/image_53ee1000.png)

### 2. Settings Modal with Version & GitHub Update Check
![Prayer Focus Settings Modal](../public/assets/aistudio/image_214d9c8c.png)

---

## 🌟 Key Architectural Features

1. **Strictly Preserves Chrome New Tab**:
   - `chrome://newtab` is never modified or overridden.
   - Your original bookmarks, Google Search, and default Chrome New Tab experience remain 100% untouched.
   - The dashboard opens independently from the toolbar popup action button or direct URL.

2. **Clean Full-Width Dashboard (No Sidebar)**:
   - Sidebar completely eliminated in favor of an expansive dark emerald glassmorphism layout.
   - Live Dhaka clock and Bengali calendar date.
   - Next prayer banner with live 1-second countdown.
   - 5 daily prayer cards with actual honest recording actions (`পড়েছি` / `ছুটেছে`).
   - Quran reading timer with start/pause/save/reset and persistent state.
   - Interactive monthly calendar with prayer history dots and date detail views.

3. **Zero Demo Data Policy**:
   - No hardcoded fake statistics or fabricated historical logs.
   - Fresh installation displays: `"আজকের কোনো কার্যক্রম এখনো রেকর্ড করা হয়নি।"`.
   - Real-time JavaScript calculations based strictly on user storage entries.

4. **Automatic Namaz-Time Popup & Website Focus Lock**:
   - When a prayer starts, an elegant full-screen overlay appears on supported websites.
   - **Exactly Two Buttons**:
     - **Button 1**: `✓ আমি নামাজে যাচ্ছি` (Activates an 8-minute focus session with full website block overlay).
     - **Button 2**: `৫ মিনিট পরে মনে করিয়ে দিন` (Snoozes reminders for exactly 5 minutes without duplicate alerts).
   - Rotating library of 62+ verified authentic Bengali Quran verses and Hadith citations.

5. **Manifest V3 Background Service Worker**:
   - Uses `chrome.alarms` for alarm scheduling (no unstable `setInterval` background loops).
   - Idempotent session state machine (`scheduled`, `notified`, `snoozed`, `focus_active`).
   - Robust recovery across Chrome restarts and suspension.

---

## 🚀 How to Install in Google Chrome (Developer Mode)

1. **Download / Extract**:
   - Download the file `prayer-focus-v2.2.0.zip` or use the `prayer-focus-v2` directory.
   - Unzip if using the zip archive so you have the `prayer-focus-v2` folder containing `manifest.json`.
2. **Open Chrome Extension Manager**:
   - In Google Chrome address bar, navigate to: `chrome://extensions/`
3. **Enable Developer Mode**:
   - Toggle the switch labeled **Developer mode** in the top-right corner.
4. **Load Unpacked**:
   - Click the **Load unpacked** button in the top-left.
   - Select the `prayer-focus-v2` directory.
5. **Pin and Use**:
   - Click the puzzle icon in Chrome's toolbar and pin **Prayer Focus**.
   - Click the icon to view current and next prayer timings, or click **ড্যাশবোর্ড খুলুন** to open the full dashboard.

---

## 📁 File Structure

```text
prayer-focus-v2/
├── manifest.json
├── background/
│   ├── service-worker.js
│   ├── scheduler.js
│   ├── notification-manager.js
│   └── session-manager.js
├── content/
│   ├── content.js
│   └── overlay.css
├── popup/
│   ├── popup.html
│   ├── popup.js
│   └── popup.css
├── dashboard/
│   ├── dashboard.html
│   ├── dashboard.js
│   └── dashboard.css
├── modules/
│   ├── storage.js
│   ├── prayer-api.js
│   ├── timezone.js
│   ├── quotes.js
│   ├── calendar.js
│   ├── quran-timer.js
│   └── prayer-tracker.js
├── assets/
│   └── icons/
│       ├── icon16.png
│       ├── icon32.png
│       ├── icon48.png
│       └── icon128.png
├── tests/
│   └── prayer-engine.test.js
└── README.md
```

---

## 🔒 Known Browser Limitations
- **Chrome Internal Pages**: Google Chrome security policy strictly prevents extensions from injecting content scripts or blocking `chrome://`, `chrome-extension://`, and the Chrome Web Store. The extension UI clearly informs the user of this browser sandbox standard.


## v2.2.13 — Bangladesh prayer timetable & Tahajjud

- Prayer times now try the Islamic Foundation Bangladesh timetable distributed by Prothom Alo (`services.prothomalo.com/api/prayer-time?v=1`) first.
- Chattogram district corrections follow the Bangladesh widget's published district offsets (Sehri/Fajr-side −2 minutes; Maghrib/Isha-side −8 minutes).
- The Calculation Method and Asr school remain configurable for the AlAdhan calculation fallback and non-Bangladesh locations. They do not overwrite Bangladesh authority-published times.
- Removed fixed seasonal fallback prayer times. If live services are unavailable, the extension uses a same-day stored schedule or a clearly labelled calculation fallback; it does not invent fixed clock times.
- Added a Tahajjud window inside Quran Reading Timer: Isha-to-Fajr start/end and a live countdown, including the active overnight interval before Fajr.


## v2.2.14 — Tahajjud loading fix & multi-provider prayer times

- Fixed Tahajjud panel remaining on “Loading”: the dashboard now imports the missing `getPrayerEpoch` helper used by the Tahajjud countdown.
- Tahajjud times and countdown now use the selected IANA timezone rather than assuming Asia/Dhaka.
- Prayer timings are checked against up to four independent providers: Bangladesh Prothom Alo feed (when location is in Bangladesh), SITP, islamic.app, and AlAdhan.
- Providers are queried in parallel and the first valid response is selected by source priority; their values are not averaged because calculation conventions can differ.
- AlAdhan date path now uses the documented `DD-MM-YYYY` format.
- City, latitude, longitude, timezone, calculation method and Asr school are included in the cache key so old-location data cannot be reused accidentally.
- If all providers fail, only a same-day cache for the exact same location/settings is allowed; no fixed prayer-time values are fabricated.


## v2.2.16 — Live daily prayer schedule
- Fetches the selected location's current-day prayer schedule from live prayer-time APIs.
- Runs one scheduled API refresh every day at 00:05 in the selected location's timezone, then reuses today's validated schedule for minute-by-minute prayer detection.
- Displays the schedule date and API sync time in the dashboard.
- Fetches yesterday's Isha and tomorrow's Fajr from AlAdhan when available so the Tahajjud overnight window uses real adjacent-day API times rather than fixed 24-hour estimates.
- Uses the selected location timezone for the dashboard clock, date, API schedule and daily refresh alarm.
- If all providers fail, it does not silently reuse a previous day's timetable.

## v2.2.16 updates
- Added a selectable prayer-time API provider (Automatic, AlAdhan, islamic.app, SITP, or Bangladesh timetable feed).
- Added a manual **Fetch Today's Prayer Times Now** action that uses the currently selected provider and calculation settings.
- Removed the Focus Duration and Snooze Duration settings from the dashboard UI.
- Tahajjud display now explicitly shows the full window from Isha start to Fajr, with the iHadis Chattogram reference link.
- Daily reminder quotes are displayed in Bengali in both the dashboard and reminder overlay.
- Provider cache keys are separated by API selection and calculation settings; provider responses must validate against today's local date.
