import { getPrayerEpoch, toBengaliNumerals, getTodayDateString, getNowForTimezone } from '../modules/timezone.js';
import { getSettings, saveSettings, getStorageData, setStorageData } from '../modules/storage.js';
import { fetchPrayerTimings, calculateNextPrayer, getPrayerWindows, formatDisplayTime, applyTimeOffset, PRAYER_NAMES } from '../modules/prayer-api.js';
import { getDailyQuote } from '../modules/quotes.js';
import { getPrayerRecordForDate, recordPrayerStatus, getTodayStats, PRAYER_LIST } from '../modules/prayer-tracker.js';
import {
  saveQuranSession,
  getQuranReadingStats,
  getActiveTimerState,
  saveActiveTimerState,
  clearActiveTimerState
} from '../modules/quran-timer.js';
import { renderMonthlyCalendar, renderDateDetails } from '../modules/calendar.js';
import { searchGlobalCities } from '../modules/cities.js';
import { checkGitHubUpdate, getInstalledVersion } from '../modules/version-checker.js';

let isUIInitialized = false;
let isRenderingCards = false;
let currentCalYear = 2026;
let currentCalMonth = 11;
let currentSettings = null;
let dashboardLang = 'en';
let liveClockInterval = null;
let cachedSchedule = null;
let countdownTimer = null;
let statsRefreshInterval = null;

let quranIsRunning = false;
let quranStartTime = null;
let quranAccumulatedSeconds = 0;
let quranInterval = null;
let tahajjudInterval = null;
let quoteRefreshInterval = null;
let dailyRefreshInterval = null;
let lastQuoteHourKey = null;
let lastPrayerScheduleDateKey = null;
let dailyDashboardRefreshBusy = false;

async function initDashboard() {
  try {
    currentSettings = await getSettings();
    const localNow = getNowForTimezone(currentSettings.timezone || 'Asia/Dhaka');
    currentCalYear = localNow.getFullYear();
    currentCalMonth = localNow.getMonth() + 1;
    dashboardLang = currentSettings.language || 'en';

    if (!isUIInitialized) {
      setupLanguageToggle();
      setupLiveClock();
      setupSettingsModal();
      isUIInitialized = true;
    }

    await refreshDashboardData();
    if (!quoteRefreshInterval) quoteRefreshInterval = setInterval(() => refreshQuoteWhenHourChanges(), 15000);
    if (!dailyRefreshInterval) dailyRefreshInterval = setInterval(() => refreshDashboardAfterLocalMidnight(), 60000);
    if (!statsRefreshInterval) {
      statsRefreshInterval = setInterval(() => loadTodayProgress(), 30000);
    }

    if (window.location.hash === '#settings') {
      openSettingsModal();
    }
  } catch (err) {
    console.error('[Prayer Focus Dashboard init error]:', err);
  }
}

async function refreshDashboardData() {
  await loadHeaderAndSettings();
  await applyStaticI18n();
  await refreshDashboardVersionLabels();
  await loadDailyQuote();
  await loadPrayerTimingsAndCountdown();
  await loadTodayProgress();
  await initQuranTimer();
  await initCalendar();
}

const I18N = {
  en: {
    heroBadge: "Daily Islamic Wisdom & Guidance",
    nextPrayerBanner: "Next Prayer",
    startsAt: "Starts at",
    timeLimitPrefix: "Time Limit",
    countdownTitle: "Time Remaining Until Adhan",
    fivePrayers: "5 Daily Prayers Schedule & Limits",
    syncLive: "Synced with prayer-time provider",
    syncOffline: "Offline Standard Schedule (Chattogram)",
    syncCache: "Stored Offline Schedule (Cached)",
    currentBadge: "Current Window",
    presentWindow: "Current Window (Present Salah)",
    presentSalahStatus: "Ongoing Now",
    prayed: "Prayed",
    missed: "Missed",
    prayerProgress: "Today's Prayer Progress",
    emptyProgress: "No activities recorded for today yet.",
    statPrayed: "Prayed",
    statMissed: "Missed",
    statCompleted: "Completed",
    quranTimer: "Quran Reading Timer",
    btnStart: "Start",
    btnPause: "Pause",
    btnStop: "Save & Stop",
    btnReset: "Reset",
    quranToday: "Today's Reading",
    quranTotal: "Total Reading",
    quranGoal: "Daily Goal",
    mins: "mins",
    quranNote: "Self-reported timer to build a daily consistent Quran habit.",
    calTitle: "Monthly Prayer Calendar & History",
    calSub: "Actual recorded prayer history in your selected timezone",
    calPrev: "◀ Prev Month",
    calNext: "Next Month ▶",
    weekdays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    monthNames: [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ],
    modalTitle: "Settings & Configuration",
    locGroup: "Location & Timezone",
    labelCity: "City Name",
    labelLat: "Latitude",
    labelLng: "Longitude",
    labelTz: "Timezone",
    formatGroup: "Time Format & Adjustments",
    labelFormat: "Time Display Format",
    labelOffsets: "Permanent Prayer Adjustments (Minutes - all days)",
    calcGroup: "Calculation Method",
    labelMethod: "Calculation Method",
    methodNote: "The selected API uses this calculation method where supported. Provider results are checked against today’s local date.",
    labelAsr: "Asr Juristic Method",
    remindGroup: "Reminders & Focus Mode",
    labelNotifCheckbox: "Enable automatic reminder popup when prayer starts",
    labelStrictMode: "Strict Salah Mode — repeat reminders until a prayer is recorded",
    strictModeHelp: "Repeat reminders every 10 minutes. Unmarked prayers automatically become missed at their calculated end limit.",
        quranGroup: "Quran Goal & Preferences",
    labelQuranGoalSetting: "Daily Quran Goal (Minutes)",
    labelDisplayName: "Your Name / Title",
    btnCancelSettings: "Cancel",
    btnSaveSettings: "Save Settings",
    footerText: "Prayer Focus v2.2.16 • Live daily prayer API • Selected location timezone"
  },
  bn: {
    heroBadge: "আজকের ইসলামিক উপদেশ ও দিকনির্দেশনা",
    nextPrayerBanner: "পরবর্তী ওয়াক্ত",
    startsAt: "ওয়াক্ত শুরু",
    timeLimitPrefix: "সময়সীমা",
    countdownTitle: "ওয়াক্ত শুরু হতে সময় বাকি",
    fivePrayers: "দৈনিক ৫ ওয়াক্ত সালাত ও সময়সীমা",
    syncLive: "নামাজের সময়সূচির API-তে সিঙ্ক হয়েছে",
    syncOffline: "অফলাইন স্ট্যান্ডার্ড সময়সূচি (চট্টগ্রাম)",
    syncCache: "সংরক্ষিত অফলাইন সময়সূচি (ক্যাশ)",
    currentBadge: "বর্তমান ওয়াক্ত",
    presentWindow: "বর্তমান ওয়াক্ত (চলমান সালাত)",
    presentSalahStatus: "চলমান",
    prayed: "পড়েছি",
    missed: "ছুটেছে",
    prayerProgress: "দৈনিক সালাত অগ্রগতি",
    emptyProgress: "আজকের কোনো কার্যক্রম এখনো রেকর্ড করা হয়নি।",
    statPrayed: "ওয়াক্ত আদায়",
    statMissed: "ছুটে গেছে",
    statCompleted: "দৈনিক সম্পন্ন",
    quranTimer: "কোরআন তিলাওয়াত টাইমার",
    btnStart: "শুরু করুন",
    btnPause: "বিরতি দিন",
    btnStop: "সংরক্ষণ ও শেষ",
    btnReset: "রিসেট",
    quranToday: "আজকের মোট তিলাওয়াত",
    quranTotal: "সর্বমোট তিলাওয়াত",
    quranGoal: "দৈনিক লক্ষ্য",
    mins: "মিনিট",
    quranNote: "এই টাইমার আপনার স্ব-প্রতিবেদিত অধ্যয়নের সময় রেকর্ড করে।",
    calTitle: "মাসিক সালাত ক্যালেন্ডার ও রেকর্ড",
    calSub: "আপনার নির্বাচিত টাইমজোন অনুযায়ী সংরক্ষিত সালাতের পরিসংখ্যান",
    calPrev: "◀ পূর্ববর্তী মাস",
    calNext: "পরবর্তী মাস ▶",
    weekdays: ["রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি"],
    monthNames: [
      'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ],
    modalTitle: "সেটিংস ও কনফিগারেশন",
    locGroup: "অবস্থান ও টাইমজোন",
    labelCity: "শহরের নাম",
    labelLat: "অক্ষাংশ (Latitude)",
    labelLng: "দ্রাঘিমাংশ (Longitude)",
    labelTz: "টাইমজোন",
    formatGroup: "ঘড়ির ফরম্যাট ও সময় সমন্বয়",
    labelFormat: "সময় প্রদর্শনের ফরম্যাট",
    labelOffsets: "স্থায়ী ওয়াক্ত সময় পরিবর্তন (মিনিট - সব দিনের জন্য প্রযোজ্য)",
    calcGroup: "সালাতের হিসাব পদ্ধতি",
    labelMethod: "পদ্ধতি (Calculation Method)",
    methodNote: "বাংলাদেশে পাওয়া গেলে ইসলামিক ফাউন্ডেশনের সময়সূচি ব্যবহার করা হবে। এই পদ্ধতি শুধু বিকল্প গণনা এবং বাংলাদেশের বাইরের অবস্থানের জন্য প্রযোজ্য।",
    labelAsr: "আসর মাযহাব (Juristic Method)",
    remindGroup: "রিমাইন্ডার ও ফোকাস মোড",
    labelNotifCheckbox: "ওয়াক্ত শুরু হলে স্বয়ংক্রিয় রিমাইন্ডার পপআপ ও অ্যালার্ম চালু রাখুন",
    labelStrictMode: "কঠোর সালাত মোড — রেকর্ড না করা পর্যন্ত বারবার রিমাইন্ডার দিন",
    strictModeHelp: "প্রতি ১০ মিনিটে রিমাইন্ডার আসবে। নির্ধারিত শেষ সময়ে রেকর্ড না করা সালাত স্বয়ংক্রিয়ভাবে ছুটে গেছে হিসেবে চিহ্নিত হবে।",
    labelFocusDuration: "ফোকাস সময় (মিনিট)",
    labelSnoozeDuration: "স্নুজ সময় (মিনিট)",
    quranGroup: "কোরআন লক্ষ্য ও পছন্দ",
    labelQuranGoalSetting: "দৈনিক তিলাওয়াতের লক্ষ্য (মিনিট)",
    labelDisplayName: "আপনার নাম / উপাধি",
    btnCancelSettings: "বাতিল",
    btnSaveSettings: "সংরক্ষণ করুন",
    footerText: "Prayer Focus v2.2.16 • প্রতিদিন লাইভ নামাজের সময় • নির্বাচিত লোকাল টাইমজোন"
  }
};



function setupLanguageToggle() {
  const btnEn = document.getElementById('lang-btn-en');
  const btnBn = document.getElementById('lang-btn-bn');

  const updateButtonsStyle = () => {
    if (btnEn && btnBn) {
      if (dashboardLang === 'en') {
        btnEn.style.background = '#10b981';
        btnEn.style.color = '#022c22';
        btnBn.style.background = 'transparent';
        btnBn.style.color = '#a7f3d0';
      } else {
        btnBn.style.background = '#10b981';
        btnBn.style.color = '#022c22';
        btnEn.style.background = 'transparent';
        btnEn.style.color = '#a7f3d0';
      }
    }
  };

  updateButtonsStyle();

  if (btnEn && btnBn) {
    btnEn.onclick = async () => {
      if (dashboardLang === 'en') return;
      dashboardLang = 'en';
      await saveSettings({ language: 'en' });
      updateButtonsStyle();
      await switchLanguage();
    };

    btnBn.onclick = async () => {
      if (dashboardLang === 'bn') return;
      dashboardLang = 'bn';
      await saveSettings({ language: 'bn' });
      updateButtonsStyle();
      await switchLanguage();
    };
  }
}

async function switchLanguage() {
  currentSettings = await getSettings();
  await applyStaticI18n();
  await loadDailyQuote();
  if (cachedSchedule) {
    await renderPrayerCards(cachedSchedule);
    startBannerCountdown(cachedSchedule);
  }
  await loadTodayProgress();
  await updateQuranStatsDisplay();
  await initCalendar();
}

function applyStaticI18n() {
  const dict = I18N[dashboardLang];

  const map = {
    'label-hero-badge': dict.heroBadge,
    'label-next-prayer-banner': dict.nextPrayerBanner,
    'label-countdown-title': dict.countdownTitle,
    'label-five-prayers': dict.fivePrayers,
    'label-prayer-progress': dict.prayerProgress,
    'label-quran-timer': dict.quranTimer,
    'btn-timer-start': dict.btnStart,
    'btn-timer-pause': dict.btnPause,
    'btn-timer-stop': dict.btnStop,
    'btn-timer-reset': dict.btnReset,
    'label-quran-today': dict.quranToday,
    'label-quran-total': dict.quranTotal,
    'label-quran-goal': dict.quranGoal,
    'label-quran-note': dict.quranNote,
    'label-cal-title': dict.calTitle,
    'label-cal-sub': dict.calSub,
    'cal-prev': dict.calPrev,
    'cal-next': dict.calNext,
    'label-modal-title': dict.modalTitle,
    'label-loc-group': dict.locGroup,
    'label-city': dict.labelCity,
    'label-lat': dict.labelLat,
    'label-lng': dict.labelLng,
    'label-tz': dict.labelTz,
    'label-format-group': dict.formatGroup,
    'label-format': dict.labelFormat,
    'label-offsets': dict.labelOffsets,
    'label-calc-group': dict.calcGroup,
    'label-method': dict.labelMethod,
    'label-method-note': dict.methodNote,
    'label-asr': dict.labelAsr,
    'label-remind-group': dict.remindGroup,
    'label-notif-checkbox': dict.labelNotifCheckbox,
    'label-strict-mode': dict.labelStrictMode,
    'strict-mode-help': dict.strictModeHelp,
    'label-focus-duration': dict.labelFocusDuration,
    'label-snooze-duration': dict.labelSnoozeDuration,
    'label-quran-group': dict.quranGroup,
    'label-quran-goal-setting': dict.labelQuranGoalSetting,
    'label-display-name': dict.labelDisplayName,
    'btn-cancel-settings': dict.btnCancelSettings,
    'btn-save-settings': dict.btnSaveSettings,
    'footer-text': dict.footerText
  };

  for (const [id, text] of Object.entries(map)) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }

  // Update offset prayer names
  const pKeys = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  pKeys.forEach((key) => {
    const el = document.getElementById(`offset-name-${key}`);
    if (el) {
      el.textContent = dashboardLang === 'en' ? PRAYER_NAMES[key].en : PRAYER_NAMES[key].bn;
    }
  });

  // Update calendar weekdays row
  const headerRow = document.getElementById('calendar-grid-header-row');
  if (headerRow) {
    headerRow.innerHTML = dict.weekdays.map((w) => `<span>${w}</span>`).join('');
  }
}

// 1. Live Clock & Date in selected location timezone
function setupLiveClock() {
  const clockEl = document.getElementById('live-clock');
  const dateEl = document.getElementById('live-date');

  const update = () => {
    const now = new Date();
    const timezone = currentSettings?.timezone || 'Asia/Dhaka';
    if (clockEl) {
      clockEl.textContent = now.toLocaleTimeString(dashboardLang === 'bn' ? 'bn-BD' : 'en-US', {
        timeZone: timezone, hour: 'numeric', minute: '2-digit', second: '2-digit',
        hour12: (currentSettings?.timeFormat || '12h') !== '24h'
      });
    }
    if (dateEl) {
      dateEl.textContent = now.toLocaleDateString(dashboardLang === 'bn' ? 'bn-BD' : 'en-US', {
        timeZone: timezone, weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
      });
    }
  };

  update();
  if (liveClockInterval) clearInterval(liveClockInterval);
  liveClockInterval = setInterval(update, 1000);
}

// 2. Settings & Location Display
async function loadHeaderAndSettings() {
  const settings = currentSettings || await getSettings();
  const locDisplay = document.getElementById('loc-display');
  if (locDisplay) {
    locDisplay.textContent = `${settings.cityName} (${settings.timezone})`;
  }
}

// 3. Daily Islamic Reminder
async function loadDailyQuote() {
  const timezone = currentSettings?.timezone || 'Asia/Dhaka';
  const todayStr = getTodayDateString(timezone);
  const hourKey = new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hourCycle: 'h23' }).format(new Date());
  const quote = getDailyQuote(`${todayStr}-${hourKey}`, dashboardLang);
  lastQuoteHourKey = hourKey;
  const textEl = document.getElementById('daily-quote-text');
  const refEl = document.getElementById('daily-quote-ref');
  if (textEl) {
    textEl.textContent = dashboardLang === 'bn'
      ? `"${quote.textBn}"`
      : `"${quote.textEn}"\\n${quote.textBn}`;
    textEl.style.whiteSpace = 'pre-line';
  }
  if (refEl) refEl.textContent = dashboardLang === 'bn'
    ? `— ${quote.referenceBn}`
    : `— ${quote.referenceEn} · ${quote.referenceBn}`;
}

function refreshQuoteWhenHourChanges() {
  const timezone = currentSettings?.timezone || 'Asia/Dhaka';
  const hourKey = new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hourCycle: 'h23' }).format(new Date());
  if (hourKey !== lastQuoteHourKey) loadDailyQuote();
}

async function refreshDashboardAfterLocalMidnight() {
  if (dailyDashboardRefreshBusy || !currentSettings) return;
  const today = getTodayDateString(currentSettings.timezone || 'Asia/Dhaka');
  if (today === lastPrayerScheduleDateKey) return;
  dailyDashboardRefreshBusy = true;
  try {
    const fresh = await fetchPrayerTimings(true);
    if (fresh?.timings) {
      await setStorageData({ dashboard_daily_prayer_refresh: today });
      await refreshDashboardData();
      if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) chrome.runtime.sendMessage({ action: 'RESCHEDULE_PRAYER_ALARMS', schedule: fresh });
    }
  } catch (error) {
    console.warn('[Prayer Focus] Midnight dashboard refresh failed:', error);
  } finally { dailyDashboardRefreshBusy = false; }
}

// 4. Five Daily Prayers & Next Prayer Countdown
async function loadPrayerTimingsAndCountdown() {
  const timezone = currentSettings?.timezone || 'Asia/Dhaka';
  const todayKey = getTodayDateString(timezone);
  const refreshState = await getStorageData('dashboard_daily_prayer_refresh');
  if (refreshState.dashboard_daily_prayer_refresh !== todayKey) {
    const fresh = await fetchPrayerTimings(true);
    if (fresh?.timings) await setStorageData({ dashboard_daily_prayer_refresh: todayKey });
    cachedSchedule = fresh || await fetchPrayerTimings();
  } else {
    cachedSchedule = await fetchPrayerTimings();
  }
  if (cachedSchedule?.date) lastPrayerScheduleDateKey = cachedSchedule.date;
  const dict = I18N[dashboardLang];
  const syncInfoEl = document.getElementById('sync-info');

  if (!cachedSchedule) {
    if (syncInfoEl) syncInfoEl.textContent = dashboardLang === 'bn'
      ? 'সময়সূচি পাওয়া যায়নি — ইন্টারনেট সংযোগ পরীক্ষা করুন'
      : 'Prayer times unavailable — check your internet connection';
    const cards = document.getElementById('prayer-cards-container');
    if (cards) cards.textContent = dashboardLang === 'bn' ? 'বর্তমান সময়সূচি লোড করা যায়নি।' : 'Could not load the current prayer timetable.';
    return;
  }

  if (cachedSchedule) {
    if (syncInfoEl) {
      if (cachedSchedule.isCalculatedFallback) {
        syncInfoEl.textContent = dashboardLang === 'bn'
          ? `গণনাভিত্তিক বিকল্প সময় (${cachedSchedule.methodName})`
          : `Calculated fallback (${cachedSchedule.methodName})`;
      } else if (cachedSchedule.isCachedFallback) {
        syncInfoEl.textContent = dashboardLang === 'bn' ? 'আজকের সংরক্ষিত সময়সূচি (ক্যাশ)' : 'Today\'s cached Bangladesh schedule';
      } else if (cachedSchedule.source === 'bangladesh') {
        syncInfoEl.textContent = dashboardLang === 'bn'
          ? 'বাংলাদেশের সময়সূচি • Prothom Alo feed'
          : 'Bangladesh timetable • Prothom Alo feed';
      } else {
        syncInfoEl.textContent = `${cachedSchedule.provider || 'Prayer API'} • ${cachedSchedule.methodName || 'Location-based calculation'}`;
      }
      const scheduleDate = cachedSchedule.date
        ? new Intl.DateTimeFormat(dashboardLang === 'bn' ? 'bn-BD' : 'en-US', {
            timeZone: cachedSchedule.timezone || currentSettings?.timezone || 'Asia/Dhaka',
            year: 'numeric', month: 'short', day: 'numeric'
          }).format(new Date(`${cachedSchedule.date}T12:00:00`))
        : '';
      const syncedAt = cachedSchedule.syncTime
        ? new Intl.DateTimeFormat(dashboardLang === 'bn' ? 'bn-BD' : 'en-US', {
            timeZone: cachedSchedule.timezone || currentSettings?.timezone || 'Asia/Dhaka',
            hour: 'numeric', minute: '2-digit'
          }).format(new Date(cachedSchedule.syncTime))
        : '';
      if (syncInfoEl && scheduleDate) {
        syncInfoEl.textContent += dashboardLang === 'bn'
          ? ` • আজকের সময়সূচি: ${scheduleDate}${syncedAt ? ` • API আপডেট: ${syncedAt}` : ''}`
          : ` • Today's schedule: ${scheduleDate}${syncedAt ? ` • API synced: ${syncedAt}` : ''}`;
      }
      if (cachedSchedule.providersChecked) {
        syncInfoEl.title = (cachedSchedule.providerStatus || []).map(p => `${p.provider}: ${p.ok ? 'OK' : (p.error || 'Unavailable')}`).join('\n');
      }
    }

    await renderPrayerCards(cachedSchedule);
    startBannerCountdown(cachedSchedule);
    startTahajjudCountdown(cachedSchedule);
  }
}

async function renderPrayerCards(schedule) {
  const container = document.getElementById('prayer-cards-container');
  if (!container || !schedule || !schedule.timings) return;
  if (isRenderingCards) return;
  isRenderingCards = true;

  try {
    container.innerHTML = '';

  const todayStr = getTodayDateString(currentSettings?.timezone || 'Asia/Dhaka');
  const record = await getPrayerRecordForDate(todayStr);
  const settings = currentSettings || await getSettings();
  const offsets = settings.timingOffsets || {};
  const fmt = settings.timeFormat || '12h';
  const windows = getPrayerWindows(schedule, offsets, fmt);
  const nextInfo = calculateNextPrayer(schedule, offsets);
  const dict = I18N[dashboardLang];

  PRAYER_LIST.forEach((key) => {
    const rawTime = schedule.timings[key] || '--:--';
    const offset = offsets[key] || 0;
    const adjustedTime = rawTime !== '--:--' ? applyTimeOffset(rawTime, offset) : '--:--';
    const displayFormatted = adjustedTime !== '--:--' ? formatDisplayTime(adjustedTime, fmt) : '--:--';
    const info = PRAYER_NAMES[key];
    const status = record[key] || 'none';
    const isCurrent = nextInfo && nextInfo.current && nextInfo.current.key === key;
    const win = windows[key] || {};

    const card = document.createElement('div');
    card.className = `prayer-card ${isCurrent ? 'current-active' : ''}`;

    const pName = dashboardLang === 'en' ? info.en : info.bn;
    const timeDisplay = dashboardLang === 'bn' ? toBengaliNumerals(displayFormatted) : displayFormatted;
    const winStr = dashboardLang === 'bn' ? toBengaliNumerals(win.windowBn || '') : (win.windowEn || '');
    const limitLabel = dashboardLang === 'bn' ? (win.limitBn || '') : (win.limitEn || '');

    card.innerHTML = `
      ${isCurrent ? `<div style="width: 100%; display: flex; justify-content: center;"><span class="current-window-badge">⚡ ${dict.currentBadge}</span></div>` : ''}
      <div>
        <div class="pc-name-bn">${pName}</div>
        <div class="pc-name-ar">${info.ar}</div>
      </div>
      <div class="pc-time">${timeDisplay}</div>
      <div class="pc-window">${dict.timeLimitPrefix}: ${winStr}</div>
      <div class="pc-limit">${limitLabel}</div>
      <div class="pc-actions">
        <button class="action-status-btn ${status === 'prayed' ? 'selected-prayed' : ''}" data-status="prayed">
          ${dict.prayed}
        </button>
        <button class="action-status-btn ${status === 'missed' ? 'selected-missed' : ''}" data-status="missed">
          ${dict.missed}
        </button>
      </div>
    `;

    const btnPrayed = card.querySelector('[data-status="prayed"]');
    const btnMissed = card.querySelector('[data-status="missed"]');

    btnPrayed.onclick = async () => {
      const newStatus = status === 'prayed' ? 'none' : 'prayed';
      await recordPrayerStatus(todayStr, key, newStatus);
      if (newStatus === 'prayed' && typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'ACTION_MARK_PRAYED', prayerKey: key }, () => {
          if (chrome.runtime.lastError) { /* ignore */ }
        });
      }
      await refreshAllPrayerViews();
    };

    btnMissed.onclick = async () => {
      const newStatus = status === 'missed' ? 'none' : 'missed';
      await recordPrayerStatus(todayStr, key, newStatus);
      await refreshAllPrayerViews();
    };

    container.appendChild(card);
  });
  } finally {
    isRenderingCards = false;
  }
}

function startBannerCountdown(schedule) {
  if (countdownTimer) clearInterval(countdownTimer);

  const nameEl = document.getElementById('banner-prayer-name');
  const timeEl = document.getElementById('banner-prayer-time');
  const windowEl = document.getElementById('banner-prayer-window');
  const countEl = document.getElementById('banner-countdown');

  const dict = I18N[dashboardLang];
  const settings = currentSettings || {};
  const offsets = settings.timingOffsets || {};
  const fmt = settings.timeFormat || '12h';

  const update = () => {
    const nextInfo = calculateNextPrayer(schedule, offsets);
    if (!nextInfo || !nextInfo.next) return;

    const next = nextInfo.next;
    const nextName = dashboardLang === 'en' ? next.nameEn : next.name;
    const formattedStartTime = formatDisplayTime(next.time, fmt);
    const winStr = dashboardLang === 'bn' ? next.windowBn : next.windowEn;
    const limitLabel = dashboardLang === 'bn' ? next.limitBn : next.limitEn;

    if (nameEl) nameEl.textContent = `${nextName} (${next.arabicName})`;
    if (timeEl) {
      const startText = dashboardLang === 'bn' ? toBengaliNumerals(formattedStartTime) : formattedStartTime;
      timeEl.textContent = `${dict.startsAt}: ${startText}`;
    }
    if (windowEl) {
      const displayWin = dashboardLang === 'bn' ? toBengaliNumerals(winStr) : winStr;
      windowEl.textContent = `${dict.timeLimitPrefix}: ${displayWin} (${limitLabel})`;
    }

    const presentEl = document.getElementById('banner-present-window');
    if (presentEl) {
      if (nextInfo.current) {
        const cur = nextInfo.current;
        const curName = dashboardLang === 'en' ? cur.nameEn : cur.name;
        const curWin = dashboardLang === 'bn' ? toBengaliNumerals(cur.windowBn || '') : (cur.windowEn || '');
        const curLimit = dashboardLang === 'bn' ? cur.limitBn : cur.limitEn;
        presentEl.style.display = 'inline-flex';
        presentEl.innerHTML = `<span class="dot"></span> <strong>${dict.presentWindow}: ${curName} (${cur.arabicName})</strong> &nbsp;•&nbsp; <span>${curWin} (${curLimit})</span>`;
      } else {
        presentEl.style.display = 'none';
      }
    }

    const remaining = Math.max(0, next.epoch - Date.now());
    const totalSec = Math.floor(remaining / 1000);
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;

    const formatted = `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    if (countEl) countEl.textContent = dashboardLang === 'bn' ? toBengaliNumerals(formatted) : formatted;
  };

  update();
  countdownTimer = setInterval(update, 1000);
}

// 5. Daily Progress (STRICTLY NO DEMO DATA)
async function loadTodayProgress() {
  const contentEl = document.getElementById('progress-content');
  if (!contentEl) return;

  const todayStr = getTodayDateString(currentSettings?.timezone || 'Asia/Dhaka');
  const stats = await getTodayStats(todayStr);
  const dict = I18N[dashboardLang];

  if (!stats.hasActivity) {
    contentEl.innerHTML = `
      <div class="empty-data-msg">
        ${dict.emptyProgress}
      </div>
    `;
    return;
  }

  const prayedCountStr = dashboardLang === 'bn' ? `${toBengaliNumerals(stats.prayedCount)}/৫` : `${stats.prayedCount}/5`;
  const missedCountStr = dashboardLang === 'bn' ? toBengaliNumerals(stats.missedCount) : stats.missedCount;
  const pctStr = dashboardLang === 'bn' ? `${toBengaliNumerals(stats.percentage)}%` : `${stats.percentage}%`;

  contentEl.innerHTML = `
    <div class="stats-grid-row">
      <div class="stat-pill">
        <div class="stat-num">${prayedCountStr}</div>
        <div class="stat-title">${dict.statPrayed}</div>
      </div>
      <div class="stat-pill">
        <div class="stat-num">${missedCountStr}</div>
        <div class="stat-title">${dict.statMissed}</div>
      </div>
      <div class="stat-pill">
        <div class="stat-num">${pctStr}</div>
        <div class="stat-title">${dict.statCompleted}</div>
      </div>
    </div>
    <div class="progress-bar-wrap">
      <div class="progress-bar-fill" style="width: ${stats.percentage}%;"></div>
    </div>
  `;
}

// 6. Quran Reading Timer
async function initQuranTimer() {
  const startBtn = document.getElementById('btn-timer-start');
  const pauseBtn = document.getElementById('btn-timer-pause');
  const stopBtn = document.getElementById('btn-timer-stop');
  const resetBtn = document.getElementById('btn-timer-reset');

  const settings = currentSettings || await getSettings();
  const dict = I18N[dashboardLang];
  const goalEl = document.getElementById('quran-goal-display');
  if (goalEl) {
    const goalVal = dashboardLang === 'bn' ? toBengaliNumerals(settings.dailyQuranGoalMinutes) : settings.dailyQuranGoalMinutes;
    goalEl.textContent = `${goalVal} ${dict.mins}`;
  }

  await updateQuranStatsDisplay();
  startTahajjudCountdown(cachedSchedule);

  const savedState = await getActiveTimerState();
  if (savedState) {
    quranAccumulatedSeconds = savedState.accumulatedSeconds || 0;
    if (savedState.isRunning && savedState.startTime) {
      const elapsedSince = Math.floor((Date.now() - savedState.startTime) / 1000);
      quranAccumulatedSeconds += elapsedSince;
      quranStartTime = Date.now();
      quranIsRunning = true;
      runQuranTick();
      startBtn.disabled = true;
      pauseBtn.disabled = false;
      stopBtn.disabled = false;
    } else {
      updateQuranDigits(quranAccumulatedSeconds);
      if (quranAccumulatedSeconds > 0) {
        stopBtn.disabled = false;
      }
    }
  }

  startBtn.onclick = () => {
    quranIsRunning = true;
    quranStartTime = Date.now();
    startBtn.disabled = true;
    pauseBtn.disabled = false;
    stopBtn.disabled = false;
    runQuranTick();
    saveActiveTimerState({ isRunning: true, startTime: quranStartTime, accumulatedSeconds: quranAccumulatedSeconds });
  };

  pauseBtn.onclick = () => {
    if (quranIsRunning) {
      quranIsRunning = false;
      if (quranInterval) clearInterval(quranInterval);
      const elapsed = Math.floor((Date.now() - quranStartTime) / 1000);
      quranAccumulatedSeconds += elapsed;
      startBtn.disabled = false;
      pauseBtn.disabled = true;
      saveActiveTimerState({ isRunning: false, startTime: null, accumulatedSeconds: quranAccumulatedSeconds });
    }
  };

  stopBtn.onclick = async () => {
    if (quranIsRunning) {
      const elapsed = Math.floor((Date.now() - quranStartTime) / 1000);
      quranAccumulatedSeconds += elapsed;
      quranIsRunning = false;
      if (quranInterval) clearInterval(quranInterval);
    }
    const session = await saveQuranSession(quranAccumulatedSeconds);
    quranAccumulatedSeconds = 0;
    updateQuranDigits(0);
    startBtn.disabled = false;
    pauseBtn.disabled = true;
    stopBtn.disabled = true;
    await updateQuranStatsDisplay();
  };

  resetBtn.onclick = async () => {
    quranIsRunning = false;
    if (quranInterval) clearInterval(quranInterval);
    quranAccumulatedSeconds = 0;
    updateQuranDigits(0);
    startBtn.disabled = false;
    pauseBtn.disabled = true;
    stopBtn.disabled = true;
    await clearActiveTimerState();
  };

  const manualInput = document.getElementById('input-manual-quran-mins');
  const addManualBtn = document.getElementById('btn-add-manual-quran');

  const handleManualAdd = async () => {
    if (!manualInput) return;
    const mins = parseInt(manualInput.value, 10);
    if (isNaN(mins) || mins <= 0) return;
    await saveQuranSession(mins * 60);
    manualInput.value = '';
    await updateQuranStatsDisplay();
  };

  addManualBtn?.addEventListener('click', handleManualAdd);
  manualInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleManualAdd();
    }
  });
}

function runQuranTick() {
  if (quranInterval) clearInterval(quranInterval);

  quranInterval = setInterval(() => {
    if (!quranIsRunning) return;
    const currentElapsed = Math.floor((Date.now() - quranStartTime) / 1000);
    const total = quranAccumulatedSeconds + currentElapsed;
    updateQuranDigits(total);
  }, 1000);
}

function updateQuranDigits(totalSec) {
  const hrs = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const str = `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  const el = document.getElementById('quran-timer-digits');
  if (el) el.textContent = dashboardLang === 'bn' ? toBengaliNumerals(str) : str;
}

async function updateQuranStatsDisplay() {
  const stats = await getQuranReadingStats();
  const dict = I18N[dashboardLang];
  const todayEl = document.getElementById('quran-today-mins');
  const totalEl = document.getElementById('quran-total-mins');

  const todayVal = dashboardLang === 'bn' ? toBengaliNumerals(stats.todayMinutes) : stats.todayMinutes;
  const totalVal = dashboardLang === 'bn' ? toBengaliNumerals(stats.totalMinutes) : stats.totalMinutes;

  if (todayEl) todayEl.textContent = `${todayVal} ${dict.mins}`;
  if (totalEl) totalEl.textContent = `${totalVal} ${dict.mins}`;
}

function startTahajjudCountdown(schedule) {
  if (tahajjudInterval) clearInterval(tahajjudInterval);
  const ids = (id) => document.getElementById(id);
  const startEl = ids('tahajjud-start-time');
  const endEl = ids('tahajjud-end-time');
  const countdownEl = ids('tahajjud-countdown');
  const statusEl = ids('tahajjud-status');
  const countdownLabel = ids('tahajjud-countdown-label');
  if (!startEl || !endEl || !countdownEl) return;
  if (!schedule?.timings || !schedule.timings.fajr || !schedule.timings.isha) {
    const status = ids('tahajjud-status');
    if (status) status.textContent = dashboardLang === 'bn' ? 'লাইভ ফজরের সময় পাওয়া যায়নি' : 'Live Fajr data unavailable';
    startEl.textContent = '--:--'; endEl.textContent = '--:--'; countdownEl.textContent = '--:--:--';
    if (countdownLabel) countdownLabel.textContent = dashboardLang === 'bn'
      ? 'আগামী ফজরের API সময় পাওয়া যায়নি'
      : "Tomorrow's Fajr API time unavailable";
    return;
  }

  const settings = currentSettings || {};
  const offsets = settings.timingOffsets || {};
  const fmt = settings.timeFormat || '12h';
  const today = schedule.date || getTodayDateString(currentSettings?.timezone || 'Asia/Dhaka');
  const fajrTime = applyTimeOffset(schedule.timings.fajr, offsets.fajr || 0);
  const ishaTime = applyTimeOffset(schedule.timings.isha, offsets.isha || 0);
  const prayerTimezone = settings.timezone || 'Asia/Dhaka';
  const todayFajr = getPrayerEpoch(today, fajrTime, prayerTimezone);
  const todayIsha = getPrayerEpoch(today, ishaTime, prayerTimezone);

  const tomorrowDate = (() => {
    const [y, m, d] = today.split('-').map(Number);
    const next = new Date(Date.UTC(y, m - 1, d + 1));
    return `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, '0')}-${String(next.getUTCDate()).padStart(2, '0')}`;
  })();
  const tomorrowFajr = (Number.isFinite(schedule.tomorrowFajrEpoch)
    ? schedule.tomorrowFajrEpoch
    : getPrayerEpoch(tomorrowDate, fajrTime, prayerTimezone)) + (offsets.fajr || 0) * 60000;

  // Before Fajr, prefer the provider's actual previous-night Isha. If the API
  // does not supply it, estimate the previous local date using the returned Isha
  // clock time and clearly label it as an Isha fallback (never show a blank time).
  const now = Date.now();
  const activeOvernight = now < todayFajr;
  const previousIshaFromApi = Number.isFinite(schedule.yesterdayIshaEpoch)
    ? schedule.yesterdayIshaEpoch + (offsets.isha || 0) * 60000
    : null;
  const previousLocalDate = (() => {
    const d = new Date(`${today}T12:00:00Z`);
    d.setUTCDate(d.getUTCDate() - 1);
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
  })();
  const previousIshaFallback = getPrayerEpoch(previousLocalDate, ishaTime, prayerTimezone);
  const usedIshaFallback = activeOvernight && !Number.isFinite(previousIshaFromApi);
  const previousIsha = Number.isFinite(previousIshaFromApi) ? previousIshaFromApi : previousIshaFallback;
  const startEpoch = activeOvernight ? previousIsha : todayIsha;
  const endEpoch = activeOvernight ? todayFajr : tomorrowFajr;

  const timeAt = (epoch) => new Intl.DateTimeFormat(dashboardLang === 'bn' ? 'bn-BD' : 'en-US', {
    timeZone: prayerTimezone, hour: 'numeric', minute: '2-digit',
    hour12: fmt !== '24h'
  }).format(new Date(epoch));

  startEl.textContent = usedIshaFallback
    ? (dashboardLang === 'bn' ? 'এশার পর' : 'After Isha')
    : timeAt(startEpoch);
  endEl.textContent = timeAt(endEpoch);
  if (ids('tahajjud-title')) ids('tahajjud-title').textContent = dashboardLang === 'bn' ? 'তাহাজ্জুদের সময়' : 'Tahajjud Time';
  if (ids('tahajjud-modal-heading')) ids('tahajjud-modal-heading').textContent = dashboardLang === 'bn' ? '🌙 তাহাজ্জুদের সময়' : '🌙 Tahajjud Time';
  if (ids('tahajjud-subtitle')) ids('tahajjud-subtitle').textContent = dashboardLang === 'bn' ? 'আজকের রাতের নামাজের সময়সূচি' : "Tonight's prayer window";
  if (ids('tahajjud-start-label')) ids('tahajjud-start-label').textContent = dashboardLang === 'bn' ? 'শুরু (এশার পর)' : 'Starts (After Isha)';
  if (ids('tahajjud-end-label')) ids('tahajjud-end-label').textContent = dashboardLang === 'bn' ? 'শেষ (ফজরের আগে)' : 'Ends (Before Fajr)';
  if (ids('tahajjud-date-note')) ids('tahajjud-date-note').textContent = dashboardLang === 'bn'
    ? 'তাহাজ্জুদ এশার ওয়াক্ত শুরু হওয়ার পর থেকে ফজর শুরু হওয়ার আগ পর্যন্ত আদায় করা যায়। উত্তম সময় রাতের শেষ এক-তৃতীয়াংশ।'
    : 'Tahajjud may be prayed after Isha begins and before Fajr. The most virtuous portion is the last third of the night.';

  const update = () => {
    const current = Date.now();
    const inside = current >= startEpoch && current < endEpoch;
    const target = inside ? endEpoch : (current < startEpoch ? startEpoch : tomorrowFajr);
    const remaining = Math.max(0, target - current);
    const seconds = Math.floor(remaining / 1000);
    const hh = Math.floor(seconds / 3600);
    const mm = Math.floor((seconds % 3600) / 60);
    const ss = seconds % 60;
    const digits = `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
    countdownEl.textContent = dashboardLang === 'bn' ? toBengaliNumerals(digits) : digits;
    if (countdownLabel) countdownLabel.textContent = dashboardLang === 'bn'
      ? (inside ? 'ফজর পর্যন্ত বাকি' : 'শুরু হতে বাকি')
      : (inside ? 'Time until Fajr' : 'Starts in');
    if (statusEl) {
      statusEl.textContent = dashboardLang === 'bn'
        ? (inside ? 'চলমান সময়' : 'অপেক্ষমাণ')
        : (inside ? 'IN WINDOW' : 'UPCOMING');
      statusEl.style.color = inside ? '#43e6ad' : '#9bd9c4';
    }
  };
  update();
  tahajjudInterval = setInterval(update, 1000);
}

// 7. Interactive Monthly Calendar
async function initCalendar() {
  const calLabel = document.getElementById('cal-current-label');
  const container = document.getElementById('calendar-days-container');
  const detailContainer = document.getElementById('calendar-day-detail');
  const prevBtn = document.getElementById('cal-prev');
  const nextBtn = document.getElementById('cal-next');
  const dict = I18N[dashboardLang];
  let rendering = false;

  const refreshCalendar = async () => {
    if (rendering) return;
    rendering = true;
    if (prevBtn) prevBtn.disabled = true;
    if (nextBtn) nextBtn.disabled = true;
    if (calLabel) {
      const monthName = dict.monthNames[currentCalMonth - 1];
      const yearStr = dashboardLang === 'bn' ? toBengaliNumerals(currentCalYear) : currentCalYear;
      calLabel.textContent = `${monthName} ${yearStr}`;
    }
    try {
      await renderMonthlyCalendar(container, currentCalYear, currentCalMonth, (dateStr, rec) => {
        renderDateDetails(detailContainer, dateStr, rec);
      }, dashboardLang);
    } finally {
      rendering = false;
      if (prevBtn) prevBtn.disabled = false;
      if (nextBtn) nextBtn.disabled = false;
    }
  };

  // Assign (rather than add) handlers so language/settings refreshes never
  // stack duplicate month changes. The calendar redraws in this same view.
  if (prevBtn) prevBtn.onclick = async () => {
    if (rendering) return;
    currentCalMonth--;
    if (currentCalMonth < 1) { currentCalMonth = 12; currentCalYear--; }
    await refreshCalendar();
  };
  if (nextBtn) nextBtn.onclick = async () => {
    if (rendering) return;
    currentCalMonth++;
    if (currentCalMonth > 12) { currentCalMonth = 1; currentCalYear++; }
    await refreshCalendar();
  };

  await refreshCalendar();
}

// 8. Settings Modal
function setupSettingsModal() {
  const modal = document.getElementById('settings-modal');
  const openBtn = document.getElementById('btn-show-settings');
  const closeBtn = document.getElementById('btn-close-settings');
  const cancelBtn = document.getElementById('btn-cancel-settings');
  const saveBtn = document.getElementById('btn-save-settings');
  const cityInput = document.getElementById('setting-city');
  const dropdown = document.getElementById('city-suggestions-dropdown');
  const spinner = document.getElementById('city-search-spinner');

  let searchTimeout = null;
  cityInput?.addEventListener('input', (e) => {
    const q = e.target.value.trim();
    if (searchTimeout) clearTimeout(searchTimeout);
    if (q.length < 1) {
      if (dropdown) dropdown.style.display = 'none';
      return;
    }

    if (spinner) spinner.style.display = 'inline';
    searchTimeout = setTimeout(async () => {
      const results = await searchGlobalCities(q);
      if (spinner) spinner.style.display = 'none';
      if (!dropdown) return;

      if (!results || results.length === 0) {
        dropdown.innerHTML = `<div class="city-dropdown-item" style="color: #a7f3d0; font-size: 12px; padding: 10px;">${dashboardLang === 'bn' ? 'কোনো শহর পাওয়া যায়নি' : 'No matching city found'}</div>`;
        dropdown.style.display = 'block';
        return;
      }

      dropdown.innerHTML = results.map((c, idx) => `
        <div class="city-dropdown-item" data-idx="${idx}">
          <div>
            <span class="city-name-text">${c.name}</span>
            <span class="city-country-text">, ${c.country}</span>
          </div>
          <div class="city-coords-text">${c.latitude.toFixed(2)}°, ${c.longitude.toFixed(2)}° • ${c.timezone}</div>
        </div>
      `).join('');

      dropdown.querySelectorAll('.city-dropdown-item').forEach((item) => {
        item.addEventListener('click', () => {
          const idx = parseInt(item.getAttribute('data-idx'), 10);
          const selected = results[idx];
          if (selected) {
            cityInput.value = `${selected.name}, ${selected.country}`;
            document.getElementById('setting-lat').value = selected.latitude;
            document.getElementById('setting-lng').value = selected.longitude;
            if (document.getElementById('setting-tz')) {
              document.getElementById('setting-tz').value = selected.timezone;
            }
          }
          dropdown.style.display = 'none';
        });
      });

      dropdown.style.display = 'block';
    }, 250);
  });

  document.addEventListener('click', (e) => {
    if (!cityInput?.contains(e.target) && !dropdown?.contains(e.target)) {
      if (dropdown) dropdown.style.display = 'none';
    }
  });

  openBtn?.addEventListener('click', openSettingsModal);
  closeBtn?.addEventListener('click', () => {
    modal.style.display = 'none';
    if (dropdown) dropdown.style.display = 'none';
  });
  cancelBtn?.addEventListener('click', () => {
    modal.style.display = 'none';
    if (dropdown) dropdown.style.display = 'none';
  });

  saveBtn?.addEventListener('click', async () => {
    const city = document.getElementById('setting-city').value;
    const timezone = document.getElementById('setting-tz')?.value || 'Asia/Dhaka';
    const lat = parseFloat(document.getElementById('setting-lat').value);
    const lng = parseFloat(document.getElementById('setting-lng').value);
    const method = parseInt(document.getElementById('setting-method').value, 10);
    const apiProvider = document.getElementById('setting-api-provider')?.value || 'auto';
    const asr = parseInt(document.getElementById('setting-asr').value, 10);
    const notifs = document.getElementById('setting-notifications').checked;
    const strictSalahMode = document.getElementById('setting-strict-salah').checked;
    const quranGoal = parseInt(document.getElementById('setting-quran-goal').value, 10) || 15;
    const displayName = document.getElementById('setting-display-name').value;

    const timeFormat = document.getElementById('setting-time-format')?.value || '12h';
    const offsets = {
      fajr: parseInt(document.getElementById('offset-fajr')?.value, 10) || 0,
      dhuhr: parseInt(document.getElementById('offset-dhuhr')?.value, 10) || 0,
      asr: parseInt(document.getElementById('offset-asr')?.value, 10) || 0,
      maghrib: parseInt(document.getElementById('offset-maghrib')?.value, 10) || 0,
      isha: parseInt(document.getElementById('offset-isha')?.value, 10) || 0
    };

    await saveSettings({
      cityName: city,
      latitude: lat,
      timezone,
      longitude: lng,
      calculationMethod: method,
      prayerApiProvider: apiProvider,
      asrMethod: asr,
      notificationsEnabled: notifs,
      strictSalahMode,
      strictReminderIntervalMinutes: 10,
      dailyQuranGoalMinutes: quranGoal,
      displayName,
      timeFormat,
      timingOffsets: offsets,
      language: dashboardLang
    });

    modal.style.display = 'none';
    currentSettings = await getSettings();
    cachedSchedule = await fetchPrayerTimings(true);
    if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
      chrome.runtime.sendMessage({ action: 'RESCHEDULE_PRAYER_ALARMS', schedule: cachedSchedule });
    }
    await refreshDashboardData();
  });

  const btnFetchTimes = document.getElementById('btn-fetch-prayer-times');
  btnFetchTimes?.addEventListener('click', async () => {
    const status = document.getElementById('api-fetch-status');
    btnFetchTimes.disabled = true;
    if (status) status.textContent = 'Fetching today’s prayer times from the selected API…';
    try {
      await saveSettings({
        prayerApiProvider: document.getElementById('setting-api-provider')?.value || 'auto',
        calculationMethod: parseInt(document.getElementById('setting-method')?.value || '1', 10),
        asrMethod: parseInt(document.getElementById('setting-asr')?.value || '1', 10),
        cityName: document.getElementById('setting-city')?.value || 'Chattogram, Bangladesh',
        latitude: parseFloat(document.getElementById('setting-lat')?.value || '22.3569'),
        longitude: parseFloat(document.getElementById('setting-lng')?.value || '91.7832'),
        timezone: document.getElementById('setting-tz')?.value || 'Asia/Dhaka'
      });
      currentSettings = await getSettings();
      cachedSchedule = await fetchPrayerTimings(true);
      if (cachedSchedule?.timings) {
        if (status) status.textContent = `Updated for ${cachedSchedule.date} • ${cachedSchedule.provider || 'API'} • ${cachedSchedule.methodName || ''}`;
        if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) chrome.runtime.sendMessage({ action: 'RESCHEDULE_PRAYER_ALARMS', schedule: cachedSchedule });
        await refreshDashboardData();
      } else if (status) {
        status.textContent = 'Could not fetch today’s schedule from the selected API. Check connection or choose Automatic / another provider.';
      }
    } catch (error) {
      console.error('[Prayer Focus] Manual prayer-time fetch failed:', error);
      if (status) status.textContent = `Fetch failed: ${error?.message || error}`;
    } finally { btnFetchTimes.disabled = false; }
  });

  const btnCheckUpdate = document.getElementById('btn-check-update');
  const updateStatusBox = document.getElementById('update-status-box');

  btnCheckUpdate?.addEventListener('click', async () => {
    if (!updateStatusBox) return;
    btnCheckUpdate.disabled = true;
    updateStatusBox.style.display = 'block';
    updateStatusBox.style.background = 'rgba(16,185,129,0.1)';
    updateStatusBox.style.border = '1px solid rgba(52,211,153,0.3)';
    updateStatusBox.style.color = '#a7f3d0';
    updateStatusBox.textContent = dashboardLang === 'bn'
      ? '⏳ গিটহাব রিলিজ যাচাই করা হচ্ছে...'
      : '⏳ Checking GitHub Releases...';

    try {
      const result = await checkGitHubUpdate();
      if (result.error) {
        updateStatusBox.style.background = 'rgba(239,68,68,0.15)';
        updateStatusBox.style.border = '1px solid rgba(239,68,68,0.3)';
        updateStatusBox.style.color = '#fca5a5';
        updateStatusBox.textContent = `❌ ${result.message}`;
      } else if (result.hasUpdate) {
        updateStatusBox.style.background = 'rgba(245,158,11,0.15)';
        updateStatusBox.style.border = '1px solid rgba(245,158,11,0.4)';
        updateStatusBox.style.color = '#fde68a';
        updateStatusBox.innerHTML = `
          <div style="font-weight:700; margin-bottom:4px;">🚀 ${dashboardLang === 'bn' ? `নতুন সংস্করণ: v${result.latestVersion}` : `Update available: v${result.latestVersion}`}</div>
          <div style="font-size:11px; opacity:.9; margin-bottom:8px;">${dashboardLang === 'bn' ? `বর্তমান সংস্করণ: v${toBengaliNumerals(result.currentVersion)}` : `Running version: v${result.currentVersion}`}</div>
          <a href="${result.downloadUrl}" target="_blank" rel="noopener noreferrer" style="display:inline-block; color:#022c22; background:#10b981; padding:7px 12px; border-radius:8px; font-weight:700; text-decoration:none;">
            📦 ${dashboardLang === 'bn' ? 'সর্বশেষ এক্সটেনশন ZIP ডাউনলোড' : 'Download Latest Extension ZIP'}
          </a>
          <p style="margin-top:8px; font-size:11px; line-height:1.5;">${dashboardLang === 'bn'
            ? 'ZIP extract করে পুরোনো unpacked ফোল্ডারটি replace করুন, তারপর chrome://extensions পেজে Reload চাপুন। আপনার prayer logs ও settings Chrome storage-এ থাকবে।'
            : 'For an unpacked install: extract the ZIP over your existing extension folder, then click Reload on chrome://extensions. Your saved prayer logs and settings stay in Chrome storage.'}</p>
        `;
      } else {
        updateStatusBox.style.background = 'rgba(16,185,129,0.15)';
        updateStatusBox.style.border = '1px solid rgba(52,211,153,0.4)';
        updateStatusBox.style.color = '#a7f3d0';
        updateStatusBox.textContent = dashboardLang === 'bn'
          ? `✅ সর্বশেষ সংস্করণ ব্যবহার করছেন (v${toBengaliNumerals(result.currentVersion)})।`
          : `✅ You are using the latest version (v${result.currentVersion}).`;
      }
    } catch (error) {
      updateStatusBox.style.background = 'rgba(239,68,68,0.15)';
      updateStatusBox.style.border = '1px solid rgba(239,68,68,0.3)';
      updateStatusBox.style.color = '#fca5a5';
      updateStatusBox.textContent = `❌ ${error?.message || 'Update check failed.'}`;
    } finally {
      btnCheckUpdate.disabled = false;
    }
  });
}

async function refreshDashboardVersionLabels() {
  const version = await getInstalledVersion();
  const versionLabel = document.getElementById('label-current-version');
  const footer = document.getElementById('footer-text');
  if (versionLabel) {
    versionLabel.textContent = dashboardLang === 'bn'
      ? `সংস্থাপিত সংস্করণ: v${toBengaliNumerals(version)}`
      : `Installed Version: v${version}`;
  }
  if (footer) {
    footer.textContent = dashboardLang === 'bn'
      ? `Prayer Focus v${toBengaliNumerals(version)} • New Tab সংরক্ষিত • নির্বাচিত টাইমজোন অনুযায়ী`
      : `Prayer Focus v${version} • Preserves Chrome New Tab • Location Timezone Calibrated`;
  }
}

async function openSettingsModal() {
  const modal = document.getElementById('settings-modal');
  if (!modal) return;
  const settings = await getSettings();

  document.getElementById('setting-city').value = settings.cityName;
  document.getElementById('setting-lat').value = settings.latitude;
  document.getElementById('setting-lng').value = settings.longitude;
  if (document.getElementById('setting-tz')) document.getElementById('setting-tz').value = settings.timezone || 'Asia/Dhaka';
  document.getElementById('setting-method').value = String(settings.calculationMethod);
  if (document.getElementById('setting-api-provider')) document.getElementById('setting-api-provider').value = settings.prayerApiProvider || 'auto';
  document.getElementById('setting-asr').value = String(settings.asrMethod);
  document.getElementById('setting-notifications').checked = settings.notificationsEnabled;
  document.getElementById('setting-strict-salah').checked = settings.strictSalahMode !== false;
  document.getElementById('setting-quran-goal').value = settings.dailyQuranGoalMinutes;
  document.getElementById('setting-display-name').value = settings.displayName;

  if (document.getElementById('setting-time-format')) {
    document.getElementById('setting-time-format').value = settings.timeFormat || '12h';
  }
  const offsets = settings.timingOffsets || {};
  ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].forEach((p) => {
    const el = document.getElementById(`offset-${p}`);
    if (el) el.value = offsets[p] || 0;
  });

  modal.style.display = 'flex';
}

async function refreshAllPrayerViews() {
  cachedSchedule = await fetchPrayerTimings();
  await renderPrayerCards(cachedSchedule);
  await loadTodayProgress();
  await initCalendar();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDashboard);
} else {
  initDashboard();
}
