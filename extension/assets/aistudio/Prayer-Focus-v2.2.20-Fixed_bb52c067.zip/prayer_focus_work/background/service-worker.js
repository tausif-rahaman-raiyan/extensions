import { setupAlarms, scheduleNextDailyRefresh, schedulePrayerEndAlarms, PRAYER_CHECK_ALARM, PRAYER_DAILY_REFRESH_ALARM, PRAYER_END_ALARM_PREFIX, checkPrayerSchedule, notifyOpenTabsToShowOverlay } from './scheduler.js';
import { getActiveSession, setActiveSession, startFocusSession, snoozeSession, finishPrayerSession, shouldShowReminderOverlay } from './session-manager.js';
import { fetchPrayerTimings } from '../modules/prayer-api.js';
import { getDailyQuote } from '../modules/quotes.js';
import { getDateStringForTimezone } from '../modules/timezone.js';
import { getSettings, setStorageData } from '../modules/storage.js';
import { recordPrayerStatus, getPrayerRecordForDate } from '../modules/prayer-tracker.js';

// Synchronous event listener registrations
if (typeof chrome !== 'undefined') {
  // Install & Startup Lifecycle
  chrome.runtime.onInstalled.addListener(async (details) => {
    console.log('[Prayer Focus] Extension Installed / Updated:', details.reason);
    await setupAlarms();
    await checkPrayerSchedule(false);
  });

  chrome.runtime.onStartup.addListener(async () => {
    console.log('[Prayer Focus] Browser started up.');
    await setupAlarms();
    await checkPrayerSchedule(false);
  });

  // Alarms trigger
  if (chrome.alarms) {
    chrome.alarms.onAlarm.addListener(async (alarm) => {
      if (alarm.name === PRAYER_DAILY_REFRESH_ALARM) {
        // Refresh automatically each local day; always schedule the next run, even
        // when the provider is offline or a request fails.
        try {
          const freshSchedule = await fetchPrayerTimings(true);
          const settings = await getSettings();
          const today = getDateStringForTimezone(new Date(), settings.timezone || 'Asia/Dhaka');
          if (freshSchedule?.timings) await setStorageData({ dashboard_daily_prayer_refresh: today });
          await checkPrayerSchedule(true);
        } catch (error) {
          console.error('[Prayer Focus] Automatic daily prayer refresh failed:', error);
        } finally {
          await scheduleNextDailyRefresh();
        }
      } else if (alarm.name === PRAYER_CHECK_ALARM) {
        await checkPrayerSchedule(true);
      } else if (alarm.name.startsWith(PRAYER_END_ALARM_PREFIX)) {
        const [, dateStr, prayerKey] = alarm.name.split(':');
        try {
          const schedule = await fetchPrayerTimings();
          const record = await getPrayerRecordForDate(dateStr, schedule);
          const session = await getActiveSession();

          if (record?.[prayerKey] === 'missed' && session?.date === dateStr && session?.prayerKey === prayerKey) {
            await setActiveSession({
              ...session,
              state: 'missed',
              completedAt: Date.now(),
              snoozeUntil: null,
              focusStart: null,
              focusEnd: null
            });
          }
          notifyOpenTabsToShowOverlay();
          await checkPrayerSchedule(false);
        } catch (error) {
          console.error('[Prayer Focus] Prayer-end alarm failed:', error);
        }
      }
    });
  }

  // Dismiss open overlays as soon as the dashboard records prayed/missed.
  chrome.storage.onChanged.addListener((changes, areaName) => {
    const session = changes.active_prayer_session?.newValue;
    if (areaName === 'local' && session && ['prayed', 'missed'].includes(session.state)) {
      notifyOpenTabsToShowOverlay();
    }
  });

  // Communication with content scripts, popup, and dashboard
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const handleAsync = async () => {
      if (request.action === 'RESCHEDULE_PRAYER_ALARMS') {
        await scheduleNextDailyRefresh();
        if (request.schedule?.timings) await schedulePrayerEndAlarms(request.schedule);
        sendResponse({ success: true });
      } else if (request.action === 'GET_OVERLAY_STATE') {
        const session = await getActiveSession();
        const check = shouldShowReminderOverlay(session);
        const settings = await getSettings();
        const todayStr = getDateStringForTimezone(new Date(), settings.timezone || 'Asia/Dhaka');
        const userLang = settings.language || 'en';
        const hourKey = new Intl.DateTimeFormat('en-CA', {
          timeZone: settings.timezone || 'Asia/Dhaka',
          year: 'numeric', month: '2-digit', day: '2-digit',
          hour: '2-digit', hourCycle: 'h23'
        }).format(new Date());
        const quote = getDailyQuote(hourKey, userLang);

        sendResponse({
          ...check,
          session,
          quote,
          settings
        });
      } else if (request.action === 'ACTION_MARK_PRAYED') {
        // User clicked "✓ Namaz Finished" / "✓ নামাজ আদায় করেছি"
        const session = await finishPrayerSession();
        if (session && session.prayerKey) {
          const settings = await getSettings();
          const todayStr = getDateStringForTimezone(new Date(), settings.timezone || 'Asia/Dhaka');
          await recordPrayerStatus(todayStr, session.prayerKey, 'prayed');
        } else if (request.prayerKey) {
          const settings = await getSettings();
          const todayStr = getDateStringForTimezone(new Date(), settings.timezone || 'Asia/Dhaka');
          await recordPrayerStatus(todayStr, request.prayerKey, 'prayed');
        }
        if (typeof chrome !== 'undefined' && chrome.alarms) {
          chrome.alarms.clear('snoozeAlarm', () => {});
        }
        notifyOpenTabsToShowOverlay();
        sendResponse({ success: true, session });
      } else if (request.action === 'ACTION_PRAY') {
        // User clicked "আমি নামাজে যাচ্ছি"
        const settings = await getSettings();
        const duration = settings.focusDurationMinutes || 8;
        const session = await startFocusSession(duration);
        notifyOpenTabsToShowOverlay();
        sendResponse({ success: true, session });
      } else if (request.action === 'ACTION_SNOOZE') {
        // User clicked "৫ মিনিট পরে মনে করিয়ে দিন"
        const settings = await getSettings();
        const snoozeMin = settings.snoozeMinutes || 5;
        const session = await snoozeSession(snoozeMin);
        notifyOpenTabsToShowOverlay();
        sendResponse({ success: true, session });
      } else if (request.action === 'TRIGGER_TEST_REMINDER') {
        // For testing purposes
        const session = {
          id: `test_${Date.now()}`,
          date: getDateStringForTimezone(new Date(), (await getSettings()).timezone || 'Asia/Dhaka'),
          prayerKey: request.prayerKey || 'dhuhr',
          prayerEpoch: Date.now(),
          state: 'notified',
          notifiedAt: Date.now(),
          snoozeUntil: null,
          focusStart: null,
          focusEnd: null
        };
        await setActiveSession(session);
        notifyOpenTabsToShowOverlay();
        sendResponse({ success: true, session });
      }
    };

    handleAsync().catch((error) => {
      console.error('[Prayer Focus] Message handler failed:', error);
      try {
        sendResponse({ success: false, error: error?.message || 'An unexpected error occurred.' });
      } catch (responseError) {
        console.warn('[Prayer Focus] Could not send error response:', responseError);
      }
    });
    return true; // Keep message channel open for async response
  });
}
